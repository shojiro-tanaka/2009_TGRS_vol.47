#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <Winsock2.h>

// main
//
int main(int argc, char *argv[]){
    
    FILE *fp;

	unsigned long i, fmax;
	unsigned long *data, temp;
	
	struct stat statbuf;

    printf("Swap Endian for 32bit binary file\n\n");
    printf("Copyright (C)1991-2003 Masahiro Fukui, (C)2007 Shojiro Tanaka.\n");
    printf("All Rights Reserved??\n\n");
    printf("Usage : SwapEndian.exe inputfile(32bit binary file)\n\n\n");

    if ((fp=fopen(argv[1],"r"))==NULL){
        printf("file not found: %s \n",argv[1]);
        exit(1);
    }


    if( stat(argv[1] ,&statbuf ) ==-1 ) exit(1);

	fmax=statbuf.st_size; /* file size */

	data=(long *)malloc(fmax*sizeof(long));

	if ((fp=fopen(argv[1],"rb"))==NULL) {
		printf("file not found: %s \n",argv[1]);
		exit(1);
	}


	fread(data,sizeof(char),fmax,fp);


	/* Swap Endian */
	for(i=0;i<fmax/4;i++){

	    temp=data[i];
	    data[i]=ntohl(temp); 
		/* The Windows Sockets ntohl function converts a u_long from TCP/IP network order 
		   to host byte order (which is little-endian on Intel processors). */

	}
	fclose(fp);


	// write in a file.
	//
    if ((fp=fopen(argv[1],"wb"))==NULL){
        printf("cannot open file:%s\n",argv[1]);
        exit(1);
    }

	for(i=0;i<fmax/4;i++){
		fwrite(&data[i], sizeof(long), 1, fp);
	}


    fclose(fp);
	free(data);


	printf("Swapping endian completed.\n bye!\n");

	return EXIT_SUCCESS;
}
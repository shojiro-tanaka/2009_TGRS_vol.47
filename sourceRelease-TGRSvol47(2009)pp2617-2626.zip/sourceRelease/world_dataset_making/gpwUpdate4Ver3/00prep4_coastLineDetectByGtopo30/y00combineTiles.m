clear;

Big = zeros(2400,1920);

load  'e100n90coastDetect';
Big(   1:1200,  1: 960) = E100N90(1:1200,1:960); clear E100N90;

load  'e100n40coastDetect';
Big(1201:2400,  1: 960) = E100N40(1:1200,1:960); clear E100N40;

load  'e140n90coastDetect';
Big(   1:1200,961:1920) = E140N90(1:1200,1:960); clear E140N90;

load  'e140n40coastDetect';
Big(1201:2400,961:1920) = E140N40(1:1200,1:960); clear E140N40;

save 'combinedTiles2x2northEastAsia' Big;


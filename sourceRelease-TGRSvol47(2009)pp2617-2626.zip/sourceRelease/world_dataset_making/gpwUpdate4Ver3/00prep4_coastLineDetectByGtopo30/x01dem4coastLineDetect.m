clear;

load 'demCheckSavedAll_e100n40'; clear count1;

% 6000x4800
% NODATA -9999 --> water surface except lakes!

A1 = A1;
B1 = zeros(1200,960);
C1 = zeros(1200,960);
E  = zeros(1200,960);
for i = 1:960
   x = 5*(i-1);
   for j = 1:1200
      y = 5*(j-1);
      Z = A1(y+1:y+5, x+1:x+5);
      B1(j, i) = max(max(Z));
      C1(j, i) = min(min(Z));
        if B1(j, i) == C1(j, i) 
          E(j, i)=0;
        else 
          E(j, i)=1;
        end
   end
end
clear B1 C1 Z;

image(100*E)

E100N40=E;

save 'e100n40coastDetect' E100N40;

%fidW = fopen('coastLineDetect4GPWv3_e100n40.data', 'w');
%fprintf(fidW, '%g ', E);
%fclose (fidW);

clear;

load  'combinedTiles2x2northEastAsia';

MatchRegion = Big(961:1680,1:1200); clear Big;
image(100*MatchRegion)

save 'waterSurfaceWarmAsia' MatchRegion;


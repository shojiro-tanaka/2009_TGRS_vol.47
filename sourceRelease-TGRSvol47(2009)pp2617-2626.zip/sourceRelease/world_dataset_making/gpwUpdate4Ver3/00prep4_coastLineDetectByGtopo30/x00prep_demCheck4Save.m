diary off; clear;

fid01 = fopen('e100n40.dat', 'r');
%fid01 = fopen('e100n90.dat', 'r');
    [A1, count1] = fscanf(fid01,'%d',[4800,inf]);
     A1 = A1'; %clear A1;
fclose(fid01); clear fid01 ans;

save demCheckSavedAll_e100n40 A1 count1;
%save demCheckSavedAll_e100n90 A1 count1;

clear;

M=8640; % number of columns
N=3432; % number of rows

fidR = fopen('glds90gLittleEndian.bil','rb');

A1 = fread(fidR,[M,inf],'long');
B1 = A1';   %B1 : 3432�~ 8640
fclose(fidR);
clear A1 fidR;

whos

B1 = B1(841:1560,6721:7920);
figure(1),image(B1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load water surface ata estimated from gtopo30
% see directory 00prep4_ ...
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load 'waterSurfaceWarmAsia';

D1 = zeros(90,150); 
for i = 1:150
   x = 8*i;
   for j = 1:90
      y = 8*j;
      count  = 0;  %scaler variable initialization
      notsea = 0;  %initialization
      for m = x-7:x
         for n = y-7:y
            if ( MatchRegion(n, m) == 1 ) & ( B1(n,m)>=0 )
               count = count + B1(n, m);
               notsea = notsea + 1;
            end
         end
      end
      if notsea > 0
            D1(j, i) = count/notsea;
         else
            D1(j, i) = -8888;
      end      
   end
end
clear B1;

figure(2),image(D1)

CoastAdjustGPWv3 = D1; clear D1;

save 'gpwVer3DensityCoarsen20minSqWarmAsia.mat' CoastAdjustGPWv3;


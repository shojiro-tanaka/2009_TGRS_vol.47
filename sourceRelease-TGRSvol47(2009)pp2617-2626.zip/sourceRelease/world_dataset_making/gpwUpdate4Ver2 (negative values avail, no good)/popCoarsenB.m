clear;

M=8640; % number of columns
N=3432; % number of rows

fidR = fopen('glds90giLittleEndian.bil','rb');

A1 = fread(fidR,[M,inf],'short');
B1 = A1';   %B1 : 3432�~ 8640
clear A1;

whos

k=M/8
l=N/8

D1 = zeros(l,k); 

fclose(fidR);

% �l���f�[�^������
for i = 1:l
   x = 8*i;
   for j = 1:k
      y = 8*j;
      count  = 0;  %scaler variable initialization
      notsea = 0;  %initialization
      for m = x-7:x
         for n = y-7:y
            if B1(m, n) >= 0
               count = count + B1(m, n);
               notsea = notsea + 1;
            end
         end
      end
      if notsea == 0
            D1(i, j) = -8888;
         else
            D1(i, j) = count/notsea;
      end      
   end
end

fidW = fopen('gpwVer2DensityCoarsen20minSq429x1080B.data', 'w');
fprintf(fidW, '%g ', D1);
fclose(fidW);


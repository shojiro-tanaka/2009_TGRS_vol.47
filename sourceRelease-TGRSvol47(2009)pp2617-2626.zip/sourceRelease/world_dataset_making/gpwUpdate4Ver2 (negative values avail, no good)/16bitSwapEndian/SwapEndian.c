#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <winsock2.h>



// main
//
int main(int argc, char *argv[]){
    
    FILE *fp;

	unsigned long i, fmax;
	unsigned short *data, temp;
	
	struct stat statbuf;

    printf("Swap Endian Ver 1.0\n\n");
    printf("Copyright (C)1991-2003 Masahiro Fukui.\n");
    printf("All Rights Reserved.\n\n");
    printf("Usage : SwapEndian.exe inputfile(binary file)\n\n\n");

    if ((fp=fopen(argv[1],"r"))==NULL){
        printf("file not found: %s \n",argv[1]);
        exit(1);
    }


    if( stat(argv[1] ,&statbuf ) ==-1 ) exit(1);

	fmax=statbuf.st_size; /* �o�C�i���t�@�C���T�C�Y���� */

	data=(short *)malloc(fmax*sizeof(short));

	if ((fp=fopen(argv[1],"rb"))==NULL) {
		printf("file not found: %s \n",argv[1]);
		exit(1);
	}


	fread(data,sizeof(char),fmax,fp);


	/* Swap Endian */
	for(i=0;i<fmax/2;i++){

	    temp=data[i];
	    data[i]=ntohs(temp); /* network to host short short(16bit) �� �z�X�g�o�C�g�I�[�_�[ */

	}
	fclose(fp);


	// write in a file.
	//
    if ((fp=fopen(argv[1],"wb"))==NULL){
        printf("cannot open file:%s\n",argv[1]);
        exit(1);
    }

	for(i=0;i<fmax/2;i++){
		fwrite(&data[i], sizeof(short), 1, fp);
	}


    fclose(fp);
	free(data);


	printf("Swapping endian was completed.\nbye!\n");

	return EXIT_SUCCESS;
}
clear;

Mc=1080; % number of columns (coarsened)
Nc= 429; % number of rows (coarsened)

fidR  = fopen('gpwVer2DensityCoarsen20minSq429x1080.data','r');
fidR2 = fopen('gpwVer2DensityCoarsen20minSq429x1080B.data','r');

A1 = fscanf(fidR, '%g',[Nc,inf]);
A2 = fscanf(fidR2,'%g',[Nc,inf]);
fclose(fidR);
fclose(fidR2);
clear fidR fidR2;

whos

min1 = min(min(A1))
min2 = min(min(A2))

B=zeros(Nc,Mc);
for j=1:Nc
  for i=1:Mc
    if A1(j,i) == A2(j,i) 
      B(j,i)=0;
    else
      B(j,i)=1;
    end
  end
end

max(max(B))


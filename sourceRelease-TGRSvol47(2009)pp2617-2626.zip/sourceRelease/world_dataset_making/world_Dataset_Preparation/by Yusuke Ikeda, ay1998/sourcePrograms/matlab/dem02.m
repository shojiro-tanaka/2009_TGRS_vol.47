fid02 = fopen('F:\GIS\e020n40.dat', 'r');
A2 = fscanf(fid02,'%d',[4800,inf]);
B2 = A2';
C2 = zeros(150,120);
D2 = zeros(150,120);

for i = 1:150
   x = 40*(i-1);
   for j = 1:120
      y = 40*(j-1);
      E2 = B2(x+1:x+40, y+1:y+40);
      C2(i, j) = max(max(E2));
      D2(i, j) = min(min(E2));
   end
end

fid12 = fopen('C:\GIS\e020n40.max', 'w+');
fid22 = fopen('C:\GIS\e020n40.min', 'w+');
fprintf(fid12, '%g ', C2);
fprintf(fid22, '%g ', D2);

fclose(fid02);
fclose(fid12);
fclose(fid22);
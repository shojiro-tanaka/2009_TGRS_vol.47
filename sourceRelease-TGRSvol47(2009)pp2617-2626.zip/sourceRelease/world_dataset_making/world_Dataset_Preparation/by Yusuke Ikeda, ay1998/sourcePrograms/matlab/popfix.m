fid1 = fopen('G:/Ikeda/Dsmoo/TOTAL_COV/denssmoo.asc','r');
A1 = fscanf(fid1,'%d',[4320,inf]);
B1 = A1';   %B1 : 1548�~ 4320
D1 = zeros(387,1080);   %387 = 1548/4, 1080 = 4320/4
clear A1;
fclose(fid1);

% �l���f�[�^������
for i = 1:387
   x = 4*i;
   for j = 1:1080
      y = 4*j;
      count = 0;   %������
      notsea = 0;  %������
      for m = x-3:x
         for n = y-3:y
            if B1(m, n) ~= -9999
               count = count + B1(m, n);
               notsea = notsea + 1;
            end
         end
      end
      if notsea ~= 0
         D1(i, j) = count/notsea;
      elseif notsea == 0
         D1(i, j) = -8888;
      end      
   end
end

fid = fopen('C:\GIS\popu.dat', 'w+');
fprintf(fid, '%g ', D1);
fclose(fid1);
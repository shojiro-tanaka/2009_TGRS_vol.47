min1 = fopen('C:\GIS\e020n90.min', 'r');
min2 = fopen('C:\GIS\e060n90.min', 'r');
min3 = fopen('C:\GIS\e100n90.min', 'r');
min4 = fopen('C:\GIS\e140n90.min', 'r');
min5 = fopen('C:\GIS\w020n90.min', 'r');
min6 = fopen('C:\GIS\w060n90.min', 'r');
min7 = fopen('C:\GIS\w100n90.min', 'r');
min8 = fopen('C:\GIS\w140n90.min', 'r');
min9 = fopen('C:\GIS\w180n90.min', 'r');

[Mn1, count11] = fscanf(min1, '%d', [96, inf]);
[Mn2, count12] = fscanf(min2, '%d', [96, inf]);
[Mn3, count13] = fscanf(min3, '%d', [96, inf]);
[Mn4, count14] = fscanf(min4, '%d', [96, inf]);
[Mn5, count15] = fscanf(min5, '%d', [96, inf]);
[Mn6, count16] = fscanf(min6, '%d', [96, inf]);
[Mn7, count17] = fscanf(min7, '%d', [96, inf]);
[Mn8, count18] = fscanf(min8, '%d', [96, inf]);
[Mn9, count19] = fscanf(min9, '%d', [96, inf]);

MIN = [Mn9 Mn8 Mn7 Mn6 Mn5 Mn1 Mn2 Mn3 Mn4];

min0 = fopen('C:\GIS\n90.min', 'w+');

fprintf(min0, '%g ', MIN);

fclose(min0);
fclose(min1);
fclose(min2);
fclose(min3);
fclose(min4);
fclose(min5);
fclose(min6);
fclose(min7);
fclose(min8);
fclose(min9);

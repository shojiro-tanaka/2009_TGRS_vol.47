fid03 = fopen('C:\GIS\w180s10.dat', 'r');
[A3, count3] = fscanf(fid03,'%d',[4800,inf]);
B3 = A3';
C3 = zeros(141, 120);
D3 = zeros(141, 120);
E3 = B3(1:5640,:);

for i = 1:141
   x = 40*(i-1);
   for j = 1:120
      y = 40*(j-1);
      F3 = E3(x+1:x+40, y+1:y+40);
      C3(i, j) = max(max(F3));
      D3(i, j) = min(min(F3));
   end
end

fid13 = fopen('C:\GIS\w180s10.max', 'w+');
fid23 = fopen('C:\GIS\w180s10.min', 'w+');
fprintf(fid13, '%g ', C3);
fprintf(fid23, '%g ', D3);

fclose(fid03);
fclose(fid13);
fclose(fid23);
fid = fopen('Q:/Landcv/Landcv.raw', 'rb')
A = fread(fid, [5400,inf], 'uchar');
B = A';                         %B = 2700�~ 5400
C = B(271:2205,:);         %270 = (90 - 72)*15, 2205 = 2700 - (90 - 57)*15
E = zeros(387,1080);     %387 = (2205 - 270)/5, 1080 = 5400/5
clear A
fclose(fid)

for i = 1:387
   for j = 1:1080
      forest = 0; %������
      sea = 0;    
      water = 0;  %������
      for x = 5*i-4:5*i
         for y = 5*j-4:5*j
            if (C(x, y) == 0)
               sea = sea + 1;
            elseif (C(x, y) <=120)
               forest = forest + 1;
            elseif (C(x, y) >= 220) 
               water = water + 1;
            end
         end
      end
      if (forest ~= 0)
         E(i, j) = forest/(25 - (sea +water));
      elseif (sea == 25)
         E(i, j) = -7777;
      end
   end
   i
end

[m, n] = size(E)
if ((m ~= 387) | (n ~= 1080))
   erorr('Warning : Wrong size of matrix')
end

fid = fopen('C:\GIS\lastfst.dat', 'w+')
fprintf(fid, '%g ', E);
fclose(fid)
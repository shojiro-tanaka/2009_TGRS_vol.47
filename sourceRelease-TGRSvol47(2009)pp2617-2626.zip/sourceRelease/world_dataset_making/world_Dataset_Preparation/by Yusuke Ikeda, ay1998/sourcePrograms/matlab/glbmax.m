Max1 = fopen('C:\GIS\n40.max', 'r');
Max2 = fopen('C:\GIS\n90.max', 'r');
Max3 = fopen('C:\GIS\s10.max', 'r');

[MAX1, count01] = fscanf(Max1, '%d', [150, inf]);
[MAX2, count02] = fscanf(Max2, '%d', [96, inf]);
[MAX3, count03] = fscanf(Max3, '%d', [141, inf]);

MAX0 = [MAX2; MAX1; MAX3];

Max0 = fopen('C:\GIS\world.max', 'w+');

fprintf(Max0, '%g ', MAX0);

fclose(Max0);
fclose(Max1);
fclose(Max2);
fclose(Max3);
Min1 = fopen('C:\GIS\n40.min', 'r');
Min2 = fopen('C:\GIS\n90.min', 'r');
Min3 = fopen('C:\GIS\s10.min', 'r');

[MIN1, count11] = fscanf(Min1, '%d', [150, inf]);
[MIN2, count12] = fscanf(Min2, '%d', [96, inf]);
[MIN3, count13] = fscanf(Min3, '%d', [141, inf]);

MIN0 = [MIN2; MIN1; MIN3];

Min0 = fopen('C:\GIS\world.min', 'w+');

fprintf(Min0, '%g ', MIN0);

fclose(Min0);
fclose(Min1);
fclose(Min2);
fclose(Min3);
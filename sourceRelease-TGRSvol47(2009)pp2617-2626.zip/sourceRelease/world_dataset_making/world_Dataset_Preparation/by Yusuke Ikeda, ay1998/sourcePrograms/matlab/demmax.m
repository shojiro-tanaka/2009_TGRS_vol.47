max1 = fopen('C:\GIS\e020n90.max', 'r');
max2 = fopen('C:\GIS\e060n90.max', 'r');
max3 = fopen('C:\GIS\e100n90.max', 'r');
max4 = fopen('C:\GIS\e140n90.max', 'r');
max5 = fopen('C:\GIS\w020n90.max', 'r');
max6 = fopen('C:\GIS\w060n90.max', 'r');
max7 = fopen('C:\GIS\w100n90.max', 'r');
max8 = fopen('C:\GIS\w140n90.max', 'r');
max9 = fopen('C:\GIS\w180n90.max', 'r');

[Mx1, count01] = fscanf(max1, '%d', [96, inf]);
[Mx2, count02] = fscanf(max2, '%d', [96, inf]);
[Mx3, count03] = fscanf(max3, '%d', [96, inf]);
[Mx4, count04] = fscanf(max4, '%d', [96, inf]);
[Mx5, count05] = fscanf(max5, '%d', [96, inf]);
[Mx6, count06] = fscanf(max6, '%d', [96, inf]);
[Mx7, count07] = fscanf(max7, '%d', [96, inf]);
[Mx8, count08] = fscanf(max8, '%d', [96, inf]);
[Mx9, count09] = fscanf(max9, '%d', [96, inf]);

MAX = [Mx9 Mx8 Mx7 Mx6 Mx5 Mx1 Mx2 Mx3 Mx4];

max0 = fopen('C:\GIS\n90.max', 'w+');

fprintf(max0, '%g ', MAX);

fclose(max0);
fclose(max1);
fclose(max2);
fclose(max3);
fclose(max4);
fclose(max5);
fclose(max6);
fclose(max7);
fclose(max8);
fclose(max9);

fid03 = fopen('C:\GIS\w180s10.mnf', 'r');
A3 = fscanf(fid03,'%d',[4800,inf]);
B3 = A3';
D3 = zeros(141, 120);
E3 = B3(1:5640,:);     %5640 = 6000 - (60-57)*120
clear A3;
fclose(fid03);

for i = 1:141     %141 = 5640/40
   x = 40*(i-1);
   for j = 1:120
      y = 40*(j-1);
      F3 = E3(x+1:x+40, y+1:y+40);
      D3(i, j) = min(min(F3));
   end
end

fid23 = fopen('C:\GIS\w180s10.min', 'w+');
fprintf(fid23, '%g ', D3);
fclose(fid23);
fid01 = fopen('C:\GIS\e140n90.mnf', 'r');
A1 = fscanf(fid01,'%d',[4800,inf]);
B1 = A1';
D1 = zeros(96,120);
E1 = B1(2161:6000,:);     %2160 = (90 - 72)*120
clear A1;
fclose(fid01);

for i = 1:96      %96 = (6000 - 2160)/40
   x = 40*(i-1);
   for j = 1:120
      y = 40*(j-1);
      F1 = E1(x+1:x+40, y+1:y+40);
      D1(i, j) = min(F1(:));
   end
end

fid21 = fopen('C:\GIS\e140n90.min', 'w+');
fprintf(fid21, '%g ', D1);
fclose(fid21);
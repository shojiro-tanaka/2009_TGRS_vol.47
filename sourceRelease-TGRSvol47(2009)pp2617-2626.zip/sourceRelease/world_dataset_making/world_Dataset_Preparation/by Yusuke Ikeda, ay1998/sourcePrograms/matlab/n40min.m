% �Œ�W�������߂�
fid02 = fopen('C:\GIS\w180n40.mnf', 'r');
A2 = fscanf(fid02,'%d',[4800,inf]);
B2 = A2'; %B2 : 6000 �~ 4800
D2 = zeros(150,120); %150 = 6000/40, 120 = 4800/40
clear A2;
fclose(fid02);

for i = 1:150
   x = 40*(i-1);
   for j = 1:120
      y = 40*(j-1);
      E2 = B2(x+1:x+40, y+1:y+40);
      D2(i, j) = min(E2(:));
   end
end

fid22 = fopen('C:\GIS\w180n40.min', 'w+');
fprintf(fid22, '%g ', D2);
fclose(fid22);
fid01 = fopen('C:\GIS\w180n90.dat', 'r');
[A1, count1] = fscanf(fid01,'%d',[4800,inf]);
B1 = A1';
C1 = zeros(96,120);
D1 = zeros(96,120);
E1 = B1(2161:6000,:);

for i = 1:96
   x = 40*(i-1);
   for j = 1:120
      y = 40*(j-1);
      F1 = E1(x+1:x+40, y+1:y+40);
      C1(i, j) = max(max(F1));
      D1(i, j) = min(min(F1));
   end
end

fid11 = fopen('C:\GIS\w180n90.max', 'w+');
fid21 = fopen('C:\GIS\w180n90.min', 'w+');
fprintf(fid11, '%g ', C1);
fprintf(fid21, '%g ', D1);

fclose(fid01);
fclose(fid11);
fclose(fid21);
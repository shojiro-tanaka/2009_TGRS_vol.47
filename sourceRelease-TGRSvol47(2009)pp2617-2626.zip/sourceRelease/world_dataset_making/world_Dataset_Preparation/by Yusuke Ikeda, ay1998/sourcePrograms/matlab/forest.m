fid2 = fopen('Q:/Landcv/Landcv.raw','rb');
[A2,count2] = fread(fid2,[5400,inf],'uchar');
B2 = A2';
C2 = B2(271:2205,:);
D2 = zeros(1935,5400);
E2 = zeros(387,1080);

for i = 1:1935
   for j = 1:5400
      if C2(i, j) > 0
         if C2(i, j) < 130
            D2(i, j) = 1;
         end
      end
   end
end


for i = 1:387
   x = 5*(i-1);
   for j = 1:1080
      y = 5*(j-1);
      F2 = D2(x+1:x+5, y+1:y+5);
      E2(i, j) = sum(sum(F2)');
   end
end

G2 = E2/25;

fclose(fid2);
fid2 = fopen('G:\Ikeda\matlab\frst.dat', 'w+');
fprintf(fid2, '%g ', G2);
fclose(fid2);
#include <stdio.h>

main()
{
	FILE *fp00, *fp01;
	int i, j;
	signed char n;
	char c = '\n';

	fp00 = fopen("F:/GIS/e060n40.dat", "w+");
	fp01 = fopen("F:/GIS/E060N40.DEM", "rb");

	for (i = 1; i <= 30; i++){
		for (j = 1; j <= 4800; j++){
			fscanf(fp01, "%2c", &n);
			fprintf(fp00, "%hd ", n);
		}
		fprintf(fp00, "%c", c);
	}

	fclose(fp00);
	fclose(fp01);

	return 0;
}

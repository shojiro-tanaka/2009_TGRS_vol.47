#include <stdio.h>

main()
{
	FILE *fp00, *fp01, *fp02;
	int i, m, n, diff;

	fp00 = fopen("C:/GIS/elv.dat", "w+");
	fp01 = fopen("C:/GIS/world.max", "r");
	fp02 = fopen("C:/GIS/world.min", "r");

	for (i = 1; i <= 417960; i++){
		fscanf(fp01, "%d", &m);
		fscanf(fp02, "%d", &n);
		if (m != -9999)
			diff = m - n;
		else
			diff = 0;
		fprintf(fp00, "%d ", diff);
	}

	fclose(fp00);
	fclose(fp01);
	fclose(fp02);

	return 0;
}


#include <stdio.h>

main()
{
  FILE *fp00, *fp01, *fp02;
  int i;
  short n;

  fp00 = fopen("E140N90.DEM", "rb");
  fp01 = fopen("e140n90.dat", "w+");
  fp02 = fopen("e140n90.mnf", "w+");

  for (i = 1; i <= 28800000; i++){
      fscanf(fp00, "%2c", &n);
      fprintf(fp01, "%hd ", n);
      if (n == -9999)
		  n = 9999;
      fprintf(fp02, "%hd ", n);
  }

  fclose(fp00);
  fclose(fp01);
  fclose(fp02);

  return 0;
}

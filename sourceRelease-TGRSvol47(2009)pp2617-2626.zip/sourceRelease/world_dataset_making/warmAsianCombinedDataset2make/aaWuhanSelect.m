clear;
%format compact;
format long;

fidfst  = fopen('warmasia.fst', 'r');
fidpop  = fopen('warmasia.pop', 'r');
load      'gpwVer3DensityCoarsen20minSqWarmAsia';
fidelv  = fopen('warmasia.elv', 'r');
%fidpop3 = fopen('warmasiaV3.pop', 'r');

F  = fscanf(fidfst, '%f', [90,150]);
N  = fscanf(fidpop, '%f', [90,150]);
N3 = CoastAdjustGPWv3;
R  = fscanf(fidelv, '%d', [90,150]);

fclose(fidfst);
fclose(fidpop);
fclose(fidelv);
%fclose(fidpop3);

whos

FW  = F (52:90,31:75);
NW  = N (52:90,31:75);
N3W = N3(52:90,31:75);
RW  = R (52:90,31:75);
image(RW)

save 'aaWuhan.mat' FW NW N3W RW;

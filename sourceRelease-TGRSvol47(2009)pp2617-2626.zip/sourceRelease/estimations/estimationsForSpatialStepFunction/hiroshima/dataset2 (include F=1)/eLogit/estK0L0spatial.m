diary off;
clear;

disp('*** erase former log-file. ok? (hit any-key) ***')
disp('(this matlab program list will be output to log)')
pause

t = clock;
!erase estK0L0spatial.log;
%!rm   estK0L0spatial.log;
diary('estK0L0spatial.log');
!type  estK0L0spatial.m;
%!cat  estK0L0spatial.m;
disp('      ')
disp('*** actual execution begins, ok? (hit any-key) ***')
pause
disp('      ')

load '..\B1B2matrix.mat';

minusD = 0.995*(1/min(lambda));
plusD  = 0.995*(1/max(lambda));

whos

Iterphi = 100;
% IterPhi should be an even number to make balance between positive and negative iteration.

resv    = zeros( Iterphi, 5+25 );

format long; 
count   = 0;
for phi = 0:(plusD-minusD)/(Iterphi-1):plusD
   disp('      ');
   disp('*** new iteration ***');
   phi
   count = count + 1
   W = speye(dataSize) - phi*H_mat;
   ldet   = - sum(log(1 - phi*lambda));
   
   B = B1 - phi*B2;
   z = XX'*W*logitFaddHalf;
   beta = inv(B)*z;
   betaN = beta(2:10);
   betaR = beta(11:25);
   intercep = beta(1);
   numBeta = length(beta);
   
   C = logitFaddHalf - XX*beta; 
   mse = C'*W*C/(dataSize-length(beta))
   aic=dataSize*( log(mse)-2*log(1.0+2*0.5) )+ldet+2*sum(log((F+0.5).*(1.0-F+0.5)))+2*(length(beta)+1)   

   resv( count, : ) = [count, phi, ldet, mse, aic, beta'];
end

%count   = 50;
for phi = 0:-(plusD-minusD)/(Iterphi-1):minusD
   disp('      ');
   disp('*** new iteration ***');
   phi
   count = count + 1
   W = speye(dataSize) - phi*H_mat;
   ldet   = - sum(log(1 - phi*lambda));
   
   B = B1 - phi*B2;
   z = XX'*W*logitFaddHalf;
   beta=inv(B)*z;
   betaN = beta(2:10);
   betaR = beta(11:25);
   intercep = beta(1);
   numBeta = length(beta);
    
   C = logitFaddHalf - XX*beta; 
   mse = C'*W*C/(dataSize-length(beta))
   aic=dataSize*( log(mse)-2*log(1.0+2*0.5) )+ldet+2*sum(log((F+0.5).*(1.0-F+0.5)))+2*(length(beta)+1)   

   resv( count, : ) = [count, phi, ldet, mse, aic, beta'];
end


resv = sortrows(resv, 2);

format long;
[minAIC, I] = min(resv(:,5));
minAIC
I
beta=resv(I,6:30)'
phi=resv(I,2)

save 'parmK0L0spatial.mat' resv;
elapseTime = etime(clock, t)
diary off

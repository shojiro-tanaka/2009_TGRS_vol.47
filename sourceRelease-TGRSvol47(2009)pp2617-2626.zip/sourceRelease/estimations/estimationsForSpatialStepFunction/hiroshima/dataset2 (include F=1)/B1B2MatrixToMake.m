clear;

load 'H4logit.mat';
dim_org

clear X dim_org N N3;

load 'dmyVarMatrix.txt';

dataSize      = length(dmyVarMatrix)
a0            = ones(dataSize,1);
logitFaddHalf = dmyVarMatrix(:,26);
F             = dmyVarMatrix(:,25);
XX            = [a0 dmyVarMatrix(:,1:24)]; 
clear dmyVarMatrix a0;

a  = sum(XX, 1);

B1 = zeros(25,25);

clear i j;
for i=2:10
   for j=2:16
      eval( ['B1(' num2str(i) '  ,j+9) = XX(:,' num2str(i)  '  )''*XX(:,j+9);'] );
   end
end
clear i j;
B1(11:25, 2:10) = B1(2:10,11:25)';

B1(1,:) = a ;
B1(:,1) = a';

clear i;
for i=1:25
   B1(i,i) = a(i);
end;
clear i;


m = H_mat*XX; %clear H_mat XX;

clear i j;
for i=2:10
   for j=1:dataSize
      eval( ['tmp' num2str(i) '(j, 1) = min(m(j,' num2str(i)  '),m(j,11));'] );
      eval( ['tmp' num2str(i) '(j, 2) = min(m(j,' num2str(i)  '),m(j,12));'] );
      eval( ['tmp' num2str(i) '(j, 3) = min(m(j,' num2str(i)  '),m(j,13));'] );
      eval( ['tmp' num2str(i) '(j, 4) = min(m(j,' num2str(i)  '),m(j,14));'] );
      eval( ['tmp' num2str(i) '(j, 5) = min(m(j,' num2str(i)  '),m(j,15));'] );
      eval( ['tmp' num2str(i) '(j, 6) = min(m(j,' num2str(i)  '),m(j,16));'] );
      eval( ['tmp' num2str(i) '(j, 7) = min(m(j,' num2str(i)  '),m(j,17));'] );
      eval( ['tmp' num2str(i) '(j, 8) = min(m(j,' num2str(i)  '),m(j,18));'] );
      eval( ['tmp' num2str(i) '(j, 9) = min(m(j,' num2str(i)  '),m(j,19));'] );
      eval( ['tmp' num2str(i) '(j,10) = min(m(j,' num2str(i)  '),m(j,20));'] );
      eval( ['tmp' num2str(i) '(j,11) = min(m(j,' num2str(i)  '),m(j,21));'] );
      eval( ['tmp' num2str(i) '(j,12) = min(m(j,' num2str(i)  '),m(j,22));'] );
      eval( ['tmp' num2str(i) '(j,13) = min(m(j,' num2str(i)  '),m(j,23));'] );
      eval( ['tmp' num2str(i) '(j,14) = min(m(j,' num2str(i)  '),m(j,24));'] );
      eval( ['tmp' num2str(i) '(j,15) = min(m(j,' num2str(i)  '),m(j,25));'] );
   end
end
clear i j;

clear i;
for i=2:10
   eval( ['sumElem' num2str(i) '= sum(tmp' num2str(i) ',1);'] );
   eval( ['clear tmp' num2str(i) ';'] );
end
clear i;


B2 = zeros(25,25);

B2( 2,11:25) = sumElem2 ;
B2( 3,11:25) = sumElem3 ;
B2( 4,11:25) = sumElem4 ;
B2( 5,11:25) = sumElem5 ;
B2( 6,11:25) = sumElem6 ;
B2( 7,11:25) = sumElem7 ;
B2( 8,11:25) = sumElem8 ;
B2( 9,11:25) = sumElem9;
B2(10,11:25) = sumElem10;

B2(11:25, 2:10) = B2(2:10,11:25)';

b = sum(H_mat*XX,1);
B2(1,:) = b ;
B2(:,1) = b';

clear i;
for i=1:25
   B2(i,i) = b(i);
end;
clear i;

save 'B1B2matrix.mat' dataSize logitFaddHalf F XX H_mat B1 B2 lambda;

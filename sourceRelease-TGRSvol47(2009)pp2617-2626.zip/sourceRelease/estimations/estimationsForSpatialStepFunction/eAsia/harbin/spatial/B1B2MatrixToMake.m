clear;

load 'Hharbin4logit.mat';

clear X dim_org N N3;

load 'dmyVarMatrix.txt';

dataSize      = length(dmyVarMatrix);
a0            = ones(dataSize,1);
logitFaddHalf = dmyVarMatrix(:,19);
F             = dmyVarMatrix(:,20);
XX            = [a0 dmyVarMatrix(:,1:18)]; 
clear dmyVarMatrix a0;

a  = sum(XX, 1);

%n  = a(1);
%n1 = a(2);
%n2 = a(3);
%n3 = a(4);
%n4 = a(5);
%n5 = a(6);
%n6 = a(7);
%n7 = a(8);
%n8 = a(9);
%n9 = a(10);
%r1 = a(11);
%r2 = a(12);
%r3 = a(13);
%r4 = a(14);
%r5 = a(15);
%r6 = a(16);
%r7 = a(17);
%r8 = a(18);
%r9 = a(19);

B1 = zeros(19,19);

%(manual matrix formation for B1)
%
%B1( 2,11) = XX(:, 2)'*XX(:,11);
%B1( 2,12) = XX(:, 2)'*XX(:,12);
%...
%B1( 2,19) = XX(:, 2)'*XX(:,19);
%...
%B1(10,19) = XX(:,10)'*XX(:,19);
% % %
%B1(11, 2) = XX(:,11)'*XX(:, 2);
%B1(11, 3) = XX(:,11)'*XX(:, 3);
%...
%
clear i j;
for i=2:10
   for j=2:10
      eval( ['B1(' num2str(i) '  ,j+9) = XX(:,' num2str(i)  '  )''*XX(:,j+9);'] );
      eval( ['B1(' num2str(i) '+9,  j) = XX(:,' num2str(i)  '+9)''*XX(:,  j);'] );
   end
end
clear i j;
%B1(11:19, 2:10)=B1(2:10, 11:19);

B1(1,:) = a ;
B1(:,1) = a';

clear i;
for i=1:19
   B1(i,i) = a(i);
end;
clear i;


m = H_mat*XX; %clear H_mat XX;

clear i j;
for i=2:10
   for j=1:dataSize
      eval( ['tmp' num2str(i) '(j,1) = min(m(j,' num2str(i)  '),m(j,11));'] );
      eval( ['tmp' num2str(i) '(j,2) = min(m(j,' num2str(i)  '),m(j,12));'] );
      eval( ['tmp' num2str(i) '(j,3) = min(m(j,' num2str(i)  '),m(j,13));'] );
      eval( ['tmp' num2str(i) '(j,4) = min(m(j,' num2str(i)  '),m(j,14));'] );
      eval( ['tmp' num2str(i) '(j,5) = min(m(j,' num2str(i)  '),m(j,15));'] );
      eval( ['tmp' num2str(i) '(j,6) = min(m(j,' num2str(i)  '),m(j,16));'] );
      eval( ['tmp' num2str(i) '(j,7) = min(m(j,' num2str(i)  '),m(j,17));'] );
      eval( ['tmp' num2str(i) '(j,8) = min(m(j,' num2str(i)  '),m(j,18));'] );
      eval( ['tmp' num2str(i) '(j,9) = min(m(j,' num2str(i)  '),m(j,19));'] );
   end
end
clear i j;

%(If you do the above manually:)
%
%for j=1:dataSize
%   tmp2(j, 1) = min(m(j,2),m(j,11)) ;
%   tmp2(j, 2) = min(m(j,2),m(j,12)) ;
%   tmp2(j, 3) = min(m(j,2),m(j,13)) ;
%   tmp2(j, 4) = min(m(j,2),m(j,14)) ;
%   tmp2(j, 5) = min(m(j,2),m(j,15)) ;
%   tmp2(j, 6) = min(m(j,2),m(j,16)) ;
%   tmp2(j, 7) = min(m(j,2),m(j,17)) ;
%   tmp2(j, 8) = min(m(j,2),m(j,18)) ;
%   tmp2(j, 9) = min(m(j,2),m(j,19)) ;
%
% ...
%
%   tmp10(j, 1) = min(m(j,10),m(j,11)) ;
%   tmp10(j, 2) = min(m(j,10),m(j,12)) ;
%   tmp10(j, 3) = min(m(j,10),m(j,13)) ;
%   tmp10(j, 4) = min(m(j,10),m(j,14)) ;
%   tmp10(j, 5) = min(m(j,10),m(j,15)) ;
%   tmp10(j, 6) = min(m(j,10),m(j,16)) ;
%   tmp10(j, 7) = min(m(j,10),m(j,17)) ;
%   tmp10(j, 8) = min(m(j,10),m(j,18)) ;
%   tmp10(j, 9) = min(m(j,10),m(j,19)) ;
%
%   tmp11(j, 1) = min(m(j,11),m(j, 2)) ;
%   tmp11(j, 2) = min(m(j,11),m(j, 3)) ;
%   tmp11(j, 3) = min(m(j,11),m(j, 4)) ;
%   tmp11(j, 4) = min(m(j,11),m(j, 5)) ;
%   tmp11(j, 5) = min(m(j,11),m(j, 6)) ;
%   tmp11(j, 6) = min(m(j,11),m(j, 7)) ;
%   tmp11(j, 7) = min(m(j,11),m(j, 8)) ;
%   tmp11(j, 8) = min(m(j,11),m(j, 9)) ;
%   tmp11(j, 9) = min(m(j,11),m(j,10)) ;
%
%...
%
%   tmp19(j, 1) = min(m(j,19),m(j, 2)) ;
%   tmp19(j, 2) = min(m(j,19),m(j, 3)) ;
%   tmp19(j, 3) = min(m(j,19),m(j, 4)) ;
%   tmp19(j, 4) = min(m(j,19),m(j, 5)) ;
%   tmp19(j, 5) = min(m(j,19),m(j, 6)) ;
%   tmp19(j, 6) = min(m(j,19),m(j, 7)) ;
%
%   tmp19(j, 7) = min(m(j,19),m(j, 8)) ;
%   tmp19(j, 8) = min(m(j,19),m(j, 9)) ;
%   tmp19(j, 9) = min(m(j,19),m(j,10)) ;
%end
%clear j;

clear i;
for i=2:10
   eval( ['sumElem' num2str(i) '= sum(tmp' num2str(i) ',1);'] );
   eval( ['clear tmp' num2str(i) ';'] );
end
clear i;


B2 = zeros(19,19);

B2( 2,11:19) = sumElem2 ;
B2( 3,11:19) = sumElem3 ;
B2( 4,11:19) = sumElem4 ;
B2( 5,11:19) = sumElem5 ;
B2( 6,11:19) = sumElem6 ;
B2( 7,11:19) = sumElem7 ;
B2( 8,11:19) = sumElem8 ;
B2( 9,11:19) = sumElem9;
B2(10,11:19) = sumElem10;

B2(11:19, 2:10) = B2(2:10,11:19)';

b = sum(H_mat*XX,1);
B2(1,:) = b ;
B2(:,1) = b';

clear i;
for i=1:19
   B2(i,i) = b(i);
end;
clear i;

save 'B1B2matrix.mat' dataSize logitFaddHalf F XX H_mat B1 B2 lambda;

clear;
load 'B1B2matrix.mat';
%H  = full(H_mat);
HX = full(H_mat*XX);

fidB1 = fopen('zzB1.txt','w');
fprintf(fidB1,'%3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d \n',B1');
fclose(fidB1)

fidB2 = fopen('zzB2.txt','w');
fprintf(fidB2,'%4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d %4d \n',B2');
fclose(fidB2)

fidHX = fopen('zzHX.txt','w');
fprintf(fidHX,'%3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d \n',HX');
fclose(fidHX)

fidX = fopen('zzX.txt','w');
fprintf(fidHX,'%3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d %3d \n',XX');
fclose(fidX)

%fidH = fopen('xxH.txt','w');
%fprintf(fidH, '%2d', H);
%fclose(fidH)

phi  = resv(:, 2);
ldet = resv(:, 3);
mse  = resv(:, 4);
aic  = resv(:, 5);

figure, plot(phi, ldet)
figure, plot(phi, mse)
figure, plot(phi, aic)

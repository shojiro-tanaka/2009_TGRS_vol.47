diary off; clear; 

fid	 = fopen('stepDataForMatlab.txt','rt');
tmp	 = fscanf(fid,'%f',[22,inf]);
Z	 = tmp'; clear tmp fid;

Y = Z(:,2);
X = Z(:,3:22);

XX = [ones(length(X),1) X];

format long;
beta=inv(XX'*XX)*XX'*Y


diary off; clear;

disp('*** erase former log-file. ok? (hit any-key) ***')
disp('(this matlab program list will be output to log)')
pause

!erase spErrorSpAveCond.log;
%!rm   spErrorSpAveCond.log;
diary('spErrorSpAveCond.log');
!type  spErrorSpAveCond.m;
%!cat  spErrorSpAveCond.m;
disp('      ')
disp('      ')
disp('*** actual execution begins, ok? (hit any-key) ***')
pause
disp('      ')

load japanPart; 

F=FJ; N=NJ; R=RJ;
clear FJ NJ RJ; 

[sizeY, sizeX] = size(F);

for j=1:sizeY
   for i=1:sizeX
      if ( F(j,i)==0 & N(j,i)<0 )
         F(j,i) = nan;
         N(j,i) = nan;
         R(j,i) = nan;
         else if ( N(j,i)<0 )
            N(j,i) = 0;
         end
      end
   end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ����ꐔ�x�N�g���̃��[�h
%from g1h4spatial result
%b1=     0.00014226696200;
%b2=     0.81649137827910;
%b3=     0.30632281972266;
%b4=     0.38332439123682;
%b5=    70.43378677345362;
%b6=    64.82091730539641;
%b7=     0.01247930039816;
%phi=    0.15616937030281;
load parmG1H4spatial.mat;
resv = sortrows(resv, 2); 
[minAIC, I] = min(resv(:,5)); 
beta = resv(I,8:14) 
phi  = resv(I,2) 
mse  = resv(I,4)
clear I resv minAIC;
b1=  beta(1)
b2=  beta(2)
b3=  beta(3)
b4=  beta(4)
b5=  beta(5)
b6=  beta(6)
b7=  beta(7)
clear beta;

predFpre = ones(sizeY,sizeX);
for j=1:sizeY
   for i=1:sizeX
      if isnan(F(j,i))
         predFpre(j,i) = NaN;
         elseif F(j,i) == 0
            predFpre(j,i) = NaN;
      else
         predFpre(j,i) = exp( -b1*(N(j,i)^b2) - b3 ) ...
          + b4*( 1.0/(1+exp(b5-b6*R(j,i)^b7)) - 1.0/(1+exp(b5)) );
      end
      if predFpre(j,i) > 1
         predFpre(j,i) = 1;
         elseif predFpre(j,i) < 0
            predFpre(j,i) = 0;
      end
   end
end

clear N R;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%�f�[�^���x�N�g��������
y0 = zeros(sizeY*sizeX,4); 
for j=1:sizeY 
   for i=1:sizeX 
      k=sizeX*(j-1)+i; 
      y0(k,1) = F(j,i); 
      y0(k,2) = predFpre(j,i); 
      y0(k,3) = i; 
      y0(k,4) = j; 
   end 
end 

yInd = find( ~isnan(y0(:,2)) );
y = [y0(yInd,1:4), yInd]; 
clear yInd;
lengY = length(y);
%�S�f�[�^������y0�́C��ŕ\�����`�p�Ɏg���̂Ŏ���Ă���

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%�אڍs��̃��[�h
load 'HjapanPnew.mat'; %whos
clear dim_org lambda;
K0    = inv(speye(dataSize) - phi*HjapanP);
[rowK, colK] = size(K0);
clear HjapanP;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if rowK ~= lengY 
   disp('error')
end

resvMuPos = zeros(lengY,8);

Ksig12 = K0(1,2:colK);
KSig22 = K0(2:rowK,2:colK);
y_1   = y(2:lengY,1);
mu_1  = y(2:lengY,2);
p = 1
mu1cond  = y(1,2) + Ksig12/KSig22*(y_1-mu_1)
sig1cond = mse*( K0(1,1)-(Ksig12/KSig22)*K0(2:rowK,1) )
resvMuPos(1,:) = [1,mu1cond,sig1cond,y(1,1),y(1,2),y(1,3:5)];
clear Ksig12 KSig22 y_1 mu_1 mu1cond sig1cond;

Ki = K0;
lengY
for p=2:lengY
   Ki(1,1) = K0(p,p); %k_ii
   Ki(1,2:colK) = K0(p,[1:(p-1),(p+1):colK]); %k_ia+k_ib
   Ki(2:rowK,1) = K0([1:(p-1),(p+1):rowK],p); %k_ai+k_bi
   Ki(2:p,2:p) = K0(1:(p-1),1:(p-1)); %K_aa
   Ki(2:p,(p+1):colK) = K0(1:(p-1),(p+1):colK); %K_ab
   Ki((p+1):rowK,2:p) = K0((p+1):rowK,1:(p-1)); %K_ba
   Ki((p+1):rowK,(p+1):colK) = K0((p+1):rowK,(p+1):colK); %K_bb
   k11 = Ki(1,1);
   k12 = Ki(1,2:colK);
   k21 = Ki(2:rowK,1);
   K22 = Ki(2:rowK,2:colK);
   %invK22 = inv(K22);
   y_p   = y([1:(p-1),(p+1):lengY],1);
   mu_p  = y([1:(p-1),(p+1):lengY],2);
   p
   mu1cond   = y(p,2) + k12/K22*(y_p-mu_p)
   %sig1cond  = mse*( k11 - k12/K22*k21 )
   sig1cond   = ( k11 - k12/K22*k21 )
   if mu1cond < 0
      mu1condMdfy = 0;
      else if mu1cond > 1
         mu1condMdfy = 1;
      else
         mu1condMdfy = mu1cond;
      end
   end
   resvMuPos(p,:) = [p,mu1condMdfy,sig1cond,y(p,1),y(p,2),y(p,3:5)];
end
clear k11 k12 k21 K22 y_p mu_p  p mu1cond sig1cond Ki K0;

format long;
%resvMuPos

errorCondF    = resvMuPos(:,4) - resvMuPos(:,2);
errorIndepenF = resvMuPos(:,4) - resvMuPos(:,5);

y0(resvMuPos(:,8),2)=errorCondF;

errorSp = ones(sizeY,sizeX);
for j=1:sizeY
   for i=1:sizeX
      k=sizeX*(j-1)+i; 
      errorSp(j,i)=y0(k,2);
      if errorSp(j,i)==1.0
         errorSp(j,i)=nan;
      end
   end
end

surf(1:sizeX,1:sizeY,errorSp);

msePlainCond     = errorCondF'*errorCondF / length(errorCondF)
msePlainIndepen  = errorIndepenF'*errorIndepenF / length(errorIndepenF)
clear temp; temp = sum(resvMuPos,1);
mseCond         =  temp(3)/lengY

save 'resvSpErrorCond.mat' errorSp y0 resvMuPos ...
     msePlainCond msePlainIndepen mseCond;

diary off;

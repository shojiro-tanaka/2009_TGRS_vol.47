function mse = funK2aLs2sp(beta)
global logitFaddHalf logN R dataSize sse mse W;

clear k;
for k = 2:length(beta);
   if beta(k) < 0
      beta(k) = 1e-6*abs(randn(1));
   end
end

B = ones(dataSize,1);

B = beta(1) + ...
    beta(2) * ( 1.0 - exp(beta(3)*logN) );

clear k;
for k = 1:dataSize
   if R(k) > beta(4)
      B(k) = B(k) + beta(5)*log( R(k)/beta(4) ) ;
   end
end
clear k;

for k = 1:dataSize 
   if B(k) > 1.0986
      B(k) = 1.0986; 
      else if B(k) < -1.0986;
         B(k) = -1.0986;
      end 
   end 
end 

C = logitFaddHalf - B;

sse = C'*W*C;

if sse < 0
   disp('sse negative!');
end

mse = sse/dataSize;

%%% eof %%%

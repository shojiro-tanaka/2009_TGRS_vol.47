clear;
t = clock;
global logitFaddHalf logN R dataSize W sse mse;

diary off
disp('*** erase former log-file. ok? (hit any-key) ***')
disp('(this matlab program list will be output to log)')
pause

!erase estK2aLs2spatial.log;
%!rm   estK2aLs2spatial.log;
diary('estK2aLs2spatial.log');
!type  estK2aLs2spatial.m;
%!cat  estK2aLs2spatial.m;
disp('      ')
disp('      ')
disp('%%% applied FUNCTION %%%')
disp('      ')
!type funK2aLs2sp.m;
%!cat funK2aLs2sp.m;
disp('      ')
disp('      ')
disp('*** actual execution begins, ok? (hit any-key) ***')
pause
disp('      ')

load 'Hjapan4logit.mat'; whos

minusD = 0.995*(1/min(lambda));
plusD  = 0.995*(1/max(lambda));

F      = X( :, 1);  
N      = X( :, 2);  
N3     = X( :, 3);  
R      = X( :, 4); 
logN   = log(N3+1);
logitFaddHalf = log( (F+0.5)./(1.0-F+0.5) );
clear dim_org N N3;

Iterphi = 100;
% IterPhi should be an even number to make balance between positive and negative iteration.
count   = 0;

beta0=[... 
  0.7071;
 29.9972;
  8.8421;
  0.5342;
   123.6;
  0.1512 ...
]  

resv    = zeros(Iterphi,7+length(beta0));

%options=optimset('Display','iter');
options=optimset('LargeScale','off','Display','iter');
options=optimset(options,'MaxFunEvals',1000);
options=optimset(options,'MaxIter',200);
%options=optimset(options,'TolX',1e-8);
%options=optimset(options,'TolFun',1e-8);

for phi = 0:(plusD-minusD)/(Iterphi-1):plusD
   disp('      ');
   disp('*** new iteration ***');
   phi
   count = count + 1
   W = speye(dataSize) - phi*H_mat;
   fcount = 0;
   [beta, fval, exitflag, output] = fminunc('funK2aLs2sp', beta0, options)
   ldet   = - sum(log(1 - phi*lambda));
aic=dataSize*log(fval) +ldet -2*dataSize*log(1.0+2*0.5) +2*sum(log( (F+0.5).*(1.0-F+0.5) )) +2*(length(beta)+1+1);
   resv( count, : ) = [count, phi, ldet, mse, aic, fval, exitflag, beta'];
   if mse < 0
      disp('mse negative!');
      %   return
   end
end

ncount		= 0;

for phi=0:-(plusD-minusD)/(Iterphi-1):minusD
   disp('      ');
   disp('*** new iteration ***');
   phi
   count  = count+1
   ncount = ncount - 1
   W = speye(dataSize) - phi*H_mat;
   fcount = 0;
   [beta, fval, exitflag, output] = fminunc('funK2aLs2sp', beta0, options)
   ldet   = - sum(log(1 - phi*lambda));
aic=dataSize*log(fval) +ldet -2*dataSize*log(1.0+2*0.5) +2*sum(log( (F+0.5).*(1.0-F+0.5) )) +2*(length(beta)+1+1);
   resv( count, : ) = [count, phi, ldet, mse, aic, fval, exitflag, beta'];
   if mse < 0
      disp('mse negative!');
      %   return
   end
end

resv = sortrows(resv, 2);

format long;
[minAIC, I] = min(resv(:,5));
minAIC
beta=resv(I,8:13)
phi=resv(I,2)

save 'parmK2aLs2spatial.mat' resv;
elapseTime = etime(clock, t)
diary off

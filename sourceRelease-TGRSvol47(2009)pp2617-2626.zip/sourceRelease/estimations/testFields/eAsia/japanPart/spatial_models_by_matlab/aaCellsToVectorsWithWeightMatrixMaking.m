diary off; 
clear; 
 
load aaJapanPart;  whos
  
[sizeY, sizeX] = size(FJ);  

X = zeros(sizeY*sizeX,5);  
for j=1:sizeY  
   for i=1:sizeX  
      k=sizeX*(j-1)+i;  
      X(k,1) = FJ (j,i);  
      X(k,2) = NJ (j,i);  
      X(k,3) = N3J(j,i);  
      X(k,4) = RJ (j,i);  
      X(k,5) = i;  
      X(k,6) = j;  
   end  
end  
clear FH NH N3H RH i j;  

%%%  (0 < forest areal rate <= 1) %%%
L = find( (X(:,1) > 0) & (X(:,2)>=0) & (X(:,3)>=0) );
X = X(L,:); clear L;
%%% /(0 < forest areal rate <= 1) %%%

%F      = X( :, 1);  
%N      = X( :, 2);  
%N3     = X( :, 3);  
%R      = X( :, 4); 
%x      = X( :, 5); 
%y      = X( :, 6); 

[dataSize, dim_org] = size(X);
dataSize

x	= X(:,5); Xmin=min(x);
y	= X(:,6); Ymin=min(y);
x	= x-Xmin+1;
y	= y-Ymin+1;

Xmax	= max(x);
Ymax	= max(y);
xy	= sparse(x, y, 1, Xmax, Ymax);
%image(xy)

H      = sparse( Xmax*Ymax,Xmax*Ymax );
[m, n] = size(H);

for j=2:(Ymax-1)
   for i=2:(Xmax-1)
      H(Xmax*(j-1)+i, Xmax*(j-1)     +i-1)  = 1;
      H(Xmax*(j-1)+i, Xmax*(j-1)     +i+1)  = 1;
      H(Xmax*(j-1)+i, Xmax*(j-1-1)   +i  )  = 1;
      H(Xmax*(j-1)+i, Xmax*(j-1+1)   +i  )  = 1;
   end
end

for j = 1:Ymax
   for i = 1:Xmax-1:Xmax
      if (Xmax*(j-1) + i-1 > 0)
         H(Xmax*(j-1)+i, Xmax*(j-1) + i-1) = 1;
      end
      if (Xmax*(j-1) + i+1 <= Xmax*Ymax)
         H(Xmax*(j-1)+i, Xmax*(j-1) + i+1) = 1;
      end
      if (Xmax*(j-2) + i   > 0)
         H(Xmax*(j-1)+i, Xmax*(j-2) + i  ) = 1;
      end
      if (Xmax*(j  ) + i   <= Xmax*Ymax)
         H(Xmax*(j-1)+i, Xmax*(j   ) + i  ) = 1;
      end
   end
end

for j = 1:Ymax-1:Ymax
   for i = 1:Xmax
      if (Xmax*(j-1) + i-1 > 0)
         H(Xmax*(j-1)+i, Xmax*(j-1) + i-1) = 1;
      end
      if (Xmax*(j-1) + i+1 <= Xmax*Ymax)
         H(Xmax*(j-1)+i, Xmax*(j-1) + i+1) = 1;
      end
      if (Xmax*(j-2) + i   > 0)
         H(Xmax*(j-1)+i, Xmax*(j-2) + i  ) = 1;
      end
      if (Xmax*(j  ) + i   <= Xmax*Ymax)
         H(Xmax*(j-1)+i, Xmax*(j  ) + i  ) = 1;
      end
   end
end

[mc, nc]	= size(H);
if mc ~= m | nc ~= n
   error('ERROR: Matrix size illegally changed');
end

P	= sparse( Xmax*Ymax, dataSize );
count	= 0;

for j=1:Ymax
   for i=1:Xmax
      if xy(i,j) == 1
         count=count+1;
         P(Xmax*(j-1)+i, count)=1;
      end
   end
end

if count ~= dataSize
   error('ERROR: Projection matrix formulation failed');
end

H_mat = P'*H*P;
lambda = eig(H_mat);

save 'Hjapan4logit.mat' H_mat lambda X dim_org dataSize

%elapseTime = etime(clock, t)
%diary off

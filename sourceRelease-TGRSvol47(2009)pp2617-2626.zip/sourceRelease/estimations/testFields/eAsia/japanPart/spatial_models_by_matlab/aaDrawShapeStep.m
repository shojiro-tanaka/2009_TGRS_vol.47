diary off; clear;
format long;


stepLogN=[ ...
   0          NaN;
   3.28935    -0.12908;
   3.85698     0.02799;
   4.22013    -0.02415;
   4.64596  0.00092945;
   4.95126     0.03619;
   5.28549    -0.00461;
   5.62934    -0.02444;
   6.15171    -0.01041;
   7.14971    -0.12539 ]

stepR=[ ...
   0       NaN;
   186.64 -0.04381;
   383.85  0.01675;
   560.85  0.09521;
   711.72  0.14198;
   854.74  0.17223;
  1042.90  0.28664;
  1211.36  0.31567;
  1497.18  0.33255;
  2086.68  0.32535 ]

whos

figure(1),plot (stepLogN(:,1), stepLogN(:,2), '-');
title('Japan log N vs extended logit F, GPWv3')

figure(2),plot (stepR(:,1), stepR(:,2), '-');
title('Japan R vs extended logit F, GPWv3')

diary off;

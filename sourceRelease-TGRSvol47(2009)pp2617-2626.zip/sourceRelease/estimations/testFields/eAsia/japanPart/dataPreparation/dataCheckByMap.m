clear;
load aaJapanPart;

%map='default';
%colormap(map);

Fmin  = min(min(FJ))
Fmax  = max(max(FJ))
Nmin  = min(min(NJ))
Nmax  = max(max(NJ))
N3min = min(min(N3J))
N3max = max(max(N3J))
Rmin  = min(min(RJ))
Rmax  = max(max(RJ))

fColor=[zeros(1,101);0.0:0.01:1.0;zeros(1,101)]';
%prism2(1,:)=[0 0 0];
figure(1)
colormap(brighten(fColor,0.1));
image(100*FJ)

figure(2)
colormap(brighten(hot(256),0.5));
image(NJ)

figure(3)
colormap(brighten(hot(256),0.5));
image(N3J)

cool2=cool(256);
cool2(1,:)=[0 0 0];
figure(4)
colormap(brighten(cool2,0.1));
image(RJ/5)

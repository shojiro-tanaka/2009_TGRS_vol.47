diary off; clear;
format long; 

load 'parmK2aLs2b.mat';

upperBound = log(3.0)
lowerBound = log(1.0/3.0)


for j=1:500
   R(j)  =5*(j-1);
   for i=1:40
      lnN(i)=0.3*(i-1);
         predLogitF(j,i) = beta(1) + ...
            -beta(2) * ...
            (  1.0/(1.0+exp(beta(3)-beta(4)*lnN(i))) ...
            -1.0/(1.0+exp(beta(3))) );
         if R(j) > beta(5)
            predLogitF(j,i) = predLogitF(j,i) + beta(6)*log( R(j)/beta(5) ) ;
         end
         if predLogitF(j,i) > upperBound
            predLogitF(j,i) = upperBound;
         elseif predLogitF(j,i) < lowerBound
            predLogitF(j,i) = lowerBound;
      end
   end
end

colormap([0,0,0]);
caxis([-2 -1]);
mesh(lnN,R,predLogitF);

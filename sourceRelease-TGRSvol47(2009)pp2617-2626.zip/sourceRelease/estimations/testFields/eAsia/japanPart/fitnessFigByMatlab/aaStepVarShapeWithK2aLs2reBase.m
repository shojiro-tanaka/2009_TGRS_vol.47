diary off; clear;
format long;

stepLogN=[ ... % params from model:K0L0
 0.0000000    NaN; 
 3.4833213    NaN; 
 4.1314453    0.02530;
 4.5066372   -0.14477;
 4.7950999   -0.04944;
 5.0581837    0.00851;
 5.3252133   -0.05411;
 5.6297529   -0.02246;
 6.0228664   -0.08912;
 6.5307937   -0.11472;
 7.4270183   -0.18635 ...
]
stepLogN(:,2)=stepLogN(:,2) + 0.68558; % to add the estimated value of intercept

stepR=[ ... % params from model:K0L0
   0.0000000      NaN;
  105.2857143     NaN ;
  326.5714286     0.16390 ;
  490.8333333     0.16980 ;
  652.7222222     0.22494 ;
  770.7352941     0.28867 ;
  943.3333333     0.34674 ;
      1096.46     0.36967 ;
      1270.67     0.41373 ;
      1552.74     0.37371 ;
      2125.22     0.38522 ...
]
stepR(:,2)=stepR(:,2) +  0.68558; % to add the estimated value of intercept

%B = beta(1) + ...
%    beta(2) * ...
%   - ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
%      -1.0./(1.0+exp(beta(3))) );
%
%clear k;
%for k = 1:dataSize
%   if R(k) > beta(5)
%      B(k) = B(k) + beta(6)*log( R(k)/beta(5) ) ;
%   end
%end

load 'parmK2aLs2.mat';

logN=0:0.1:7.9;
estYn = ...
    beta(1) + ...
   -beta(2) * ...
     ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
      -1.0./(1.0+exp(beta(3))) ) ;

R = 0:1:2299;
estYr(1:length(R)) = beta(1); %addition of intercept value
%estYr(1:length(R)) = 0;
clear k;
for k = 1:length(R)
   if R(k) > beta(5)
      estYr(k) = estYr(k) + beta(6)*log( R(k)/beta(5) ) ;
   end
end

whos

figure(1),plot (stepLogN(:,1), stepLogN(:,2), '*', logN, estYn, '-');
title('log N vs logit (F+0.5) with estimated values by model: K0Ls2')

figure(2),plot (stepR(:,1), stepR(:,2), '*', R, estYr, '-');
title('R vs logit (F+0.5) with estimated values by step model: K2aL0')

diary off;

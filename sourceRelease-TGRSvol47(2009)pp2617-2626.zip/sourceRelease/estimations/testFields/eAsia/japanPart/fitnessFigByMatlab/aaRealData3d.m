diary off; clear;

load 'Hjapan4logit.mat';  clear H_mat;
whos

dataSize0 = length(X)
X(dataSize0+1,1)=NaN;
X(dataSize0+1,3)=exp(14);
X(dataSize0+1,4)=NaN;

F      = X( :, 1);  
N      = X( :, 2);  
N3     = X( :, 3);  
R      = X( :, 4); 
logN   = log(N3+1);
logitFaddHalf = log( (F+0.5)./(1.0-F+0.5) );
clear X;

plot3(logN,R,logitFaddHalf,'o')
grid on
axis auto
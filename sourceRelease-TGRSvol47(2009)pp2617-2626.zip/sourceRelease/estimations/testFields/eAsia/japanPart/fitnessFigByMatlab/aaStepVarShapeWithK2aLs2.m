diary off; clear;
format long;

stepLogN=[ ... % params from model:K0Ls2
 0.0000000    NaN; 
 3.4833213  0.7604; 
 4.1314453  0.8008;
 4.5066372  0.6203;
 4.7950999  0.7243;
 5.0581837  0.7714;
 5.3252133  0.7098;
 5.6297529  0.7384;
 6.0228664  0.6813;
 6.5307937  0.6440;
 7.4270183  0.5783 ...
]
stepLogN(:,2)=stepLogN(:,2) -0.1044; % to add the estimated value of intercept

stepR=[ ... % params from model:K2aL0
   0.0000000      NaN;
  105.2857143  -0.00498  ;
  326.5714286    0.1070  ;
  490.8333333    0.1184  ;
  652.7222222    0.1880  ;
  770.7352941    0.2532  ;
  943.3333333    0.2841  ;
      1096.46    0.3224  ;
      1270.67    0.3721  ;
      1552.74    0.3454  ;
      2125.22    0.3468 ...
]
stepR(:,2)=stepR(:,2)+  0.7000; % to add the estimated value of intercept


%B = beta(1) + ...
%    beta(2) * ...
%   - ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
%      -1.0./(1.0+exp(beta(3))) );
%
%clear k;
%for k = 1:dataSize
%   if R(k) > beta(5)
%      B(k) = B(k) + beta(6)*log( R(k)/beta(5) ) ;
%   end
%end

load 'parmK2aLs2.mat';

logN=0:0.1:7.9;
estYn = ...
    beta(1) + ...
   -beta(2) * ...
     ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
      -1.0./(1.0+exp(beta(3))) ) ;

R = 0:1:2299;
estYr(1:length(R)) = beta(1); %addition of intercept value
%estYr(1:length(R)) = 0;
clear k;
for k = 1:length(R)
   if R(k) > beta(5)
      estYr(k) = estYr(k) + beta(6)*log( R(k)/beta(5) ) ;
   end
end

whos

figure(1),plot (stepLogN(:,1), stepLogN(:,2), '*', logN, estYn, '-');
title('log N vs logit (F+0.5) with estimated values by model: K0Ls2')

figure(2),plot (stepR(:,1), stepR(:,2), '*', R, estYr, '-');
title('R vs logit (F+0.5) with estimated values by step model: K2aL0')

diary off;

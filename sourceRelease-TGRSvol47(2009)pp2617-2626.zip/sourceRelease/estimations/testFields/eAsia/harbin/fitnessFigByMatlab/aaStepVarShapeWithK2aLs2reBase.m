diary off; clear;
format long;

stepLogN=[ ... % params from model:K0L0
   0.0000000    NaN; 
   2.0513713    NaN; 
   2.7168502    -0.06545; 
   3.0372575    -0.10820; 
   3.3230575    -0.00423; 
   3.6529682    -0.11364; 
   4.2099936    -0.19362; 
   4.5700935    -0.34238; 
   4.9131978    -0.24139; 
   5.1987752    -0.19282; 
   5.7205703     0.24379 ...
]
stepLogN(:,2)=stepLogN(:,2)+ 0.29217; % to add the estimated value of intercept

stepR=[ ... % params from model:K2aL0
   0.0000000      NaN;
  57.1538462      NaN;
 100.8378378      0.66089;
 135.6388889      0.52648;
 189.8974359      0.75611;
 248.2222222      0.78817;
 315.8648649      0.72599;
 415.1052632      0.75504;
 526.2432432      0.85273;
 621.8684211      0.83223;
 798.4210526      0.89468 ...
]
stepR(:,2)=stepR(:,2)+ 0.29217; % to add the estimated value of intercept


%B = beta(1) + ...
%    beta(2) * ...
%   - ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
%      -1.0./(1.0+exp(beta(3))) );
%
%clear k;
%for k = 1:dataSize
%   if R(k) > beta(5)
%      B(k) = B(k) + beta(6)*log( R(k)/beta(5) ) ;
%   end
%end

beta(1) =   0.5917;
beta(2) =   0.1861;
beta(3) =   5.5372;
beta(4) =   2.0000;
beta(5) =  40.3702;
beta(6) =   0.2293;

logN=0:0.1:7.9;
estYn = ...
    beta(1) + ...
   -beta(2) * ...
     ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
      -1.0./(1.0+exp(beta(3))) ) ;

R = 0:1:2199;
estYr(1:length(R)) = beta(1); %addition of intercept value
%estYr(1:length(R)) = 0;
clear k;
for k = 1:length(R)
   if R(k) > beta(5)
      estYr(k) = estYr(k) + beta(6)*log( R(k)/beta(5) ) ;
   end
end

whos

figure(1),plot (stepLogN(:,1), stepLogN(:,2), '*', logN, estYn, '-');
title('log N vs logit (F+0.5) with estimated values by model: K0Ls2')

figure(2),plot (stepR(:,1), stepR(:,2), '*', R, estYr, '-');
title('R vs logit (F+0.5) with estimated values by step model: K2aL0')

diary off;

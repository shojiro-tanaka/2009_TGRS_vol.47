diary off; clear;

disp('*** erase former log-file. ok? (hit any-key) ***')
disp('(this matlab program list will be output to log)')
pause

!erase aaSpErrorSpAveCond.log;
%!rm   aaSpErrorSpAveCond.log;
diary('aaSpErrorSpAveCond.log');
!type  aaSpErrorSpAveCond.m;
%!cat  aaSpErrorSpAveCond.m;
disp('      ')
disp('      ')
disp('*** actual execution begins, ok? (hit any-key) ***')
pause
disp('      ')

load aaHarbin; 

F=FH; N=NH; N3=N3H; R=RH;
clear FH NH N3H RH; 

[sizeY, sizeX] = size(F);

for j=1:sizeY
   for i=1:sizeX
      if ( F(j,i)==0 | N3(j,i)<0 | N(j,i)<0)
         F(j,i) = NaN;
         N(j,i) = NaN;
         N3(j,i)= NaN;
         R(j,i) = NaN;
      end
   end
end

logitFaddHalf = log( (F+0.5)./(1.0-F+0.5) );
logN = log(N3+1); clear N N3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load 'parmK2aLs2spatial.mat';
[minAIC, I] = min(resv(:,5)); 
minAIC 
beta=resv(I,8:13) 
phi=resv(I,2) 

upperBound = log(3.0)
lowerBound = log(1.0/3.0)

predFpre = ones(sizeY,sizeX);
for j=1:sizeY
   for i=1:sizeX
      if isnan(F(j,i))
         predFpre(j,i) = NaN;
         elseif F(j,i) == 0
            predFpre(j,i) = NaN;
      else
         predFpre(j,i) = beta(1) + ...
            -beta(2) * ...
            (  1.0/(1.0+exp(beta(3)-beta(4)*logN(j,i))) ...
            -1.0/(1.0+exp(beta(3))) );
      end
      if R(j,i) > beta(5)
          predFpre(j,i) = predFpre(j,i) + beta(6)*log( R(j,i)/beta(5) ) ;
      end
      if predFpre(j,i) > upperBound
         predFpre(j,i) = upperBound;
         elseif predFpre(j,i) < lowerBound
            predFpre(j,i) = lowerBound;
      end
   end
end

clear F logitFaddHalfR;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%�f�[�^���x�N�g��������
y0 = zeros(sizeY*sizeX,4); 
for j=1:sizeY 
   for i=1:sizeX 
      k=sizeX*(j-1)+i; 
      y0(k,1) = logitFaddHalf(j,i); 
      y0(k,2) = predFpre(j,i); 
      y0(k,3) = i; 
      y0(k,4) = j; 
   end 
end 

yInd = find( ~isnan(y0(:,2)) );
y = [y0(yInd,1:4), yInd]; 
clear yInd;
lengY = length(y);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%�אڍs��̃��[�h
load 'Hharbin4logit.mat'; %whos
clear dim_org lambda;
K0    = inv(speye(dataSize) - phi*H_mat);
[rowK, colK] = size(K0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if rowK ~= lengY 
   disp('error')
end

resvMuPos = zeros(lengY,7);

sig12 = K0(1,2:colK);
Sig22 = K0(2:rowK,2:colK);
y_1   = y(2:lengY,1);
mu_1  = y(2:lengY,2);
mu1cond  = y(1,2) + sig12/Sig22*(y_1-mu_1)
resvMuPos(1,:) = [1,mu1cond,y(1,1),y(1,2),y(1,3:5)];
clear sig12 Sig22 y_1 mu_1 mu1cond;

Ki = K0;
lengY
for p=2:lengY
   Ki(1,1) = K0(p,p); %k_ii
   Ki(1,2:colK) = K0(p,[1:(p-1),(p+1):colK]); %k_ia+k_ib
   Ki(2:rowK,1) = K0([1:(p-1),(p+1):rowK],p); %k_ai+k_bi
   Ki(2:p,2:p) = K0(1:(p-1),1:(p-1)); %K_aa
   Ki(2:p,(p+1):colK) = K0(1:(p-1),(p+1):colK); %K_ab
   Ki((p+1):rowK,2:p) = K0((p+1):rowK,1:(p-1)); %K_ba
   Ki((p+1):rowK,(p+1):colK) = ...
      K0((p+1):rowK,(p+1):colK); %K_bb
   sig12 = Ki(1,2:colK);
   Sig22 = Ki(2:rowK,2:colK);
   y_p   = y([1:(p-1),(p+1):lengY],1);
   mu_p  = y([1:(p-1),(p+1):lengY],2);
   p
   mu1cond   = y(p,2) + sig12/Sig22*(y_p-mu_p)
   if mu1cond < lowerBound
      mu1condMdfy = lowerBound;
      else if mu1cond > upperBound
         mu1condMdfy = upperBound;
      else
         mu1condMdfy = mu1cond;
      end
   end
   resvMuPos(p,:) = [p,mu1condMdfy,y(p,1),y(p,2),y(p,3:5)];
end

format long;
%resvMuPos

errorCondF = resvMuPos(:,3) - resvMuPos(:,2);
errorF = resvMuPos(:,3) -resvMuPos(:,4);

y0(resvMuPos(:,7),2)=errorCondF;

errorSp = ones(sizeY,sizeX);
for j=1:sizeY
   for i=1:sizeX
      k=sizeX*(j-1)+i; 
      errorSp(j,i)=y0(k,2);
      if errorSp(j,i)==upperBound
         errorSp(j,i)=nan;
      end
   end
end

save 'resvSpErrorCond.mat' errorSp y0;

surf(1:sizeX,1:sizeY,errorSp);

mseCond = errorCondF'*errorCondF / length(errorCondF)
mseIndepen = errorF'*errorF / length(errorF)

diary off;

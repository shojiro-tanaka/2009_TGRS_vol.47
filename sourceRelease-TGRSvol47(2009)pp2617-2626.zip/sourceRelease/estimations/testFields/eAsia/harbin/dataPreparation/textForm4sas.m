diary off; 
clear; 
 
load aaHarbin;  
  
[sizeY, sizeX] = size(FH);  

X = zeros(sizeY*sizeX,5);  
for j=1:sizeY  
   for i=1:sizeX  
      k=sizeX*(j-1)+i;  
      X(k,1) = FH (j,i);  
      X(k,2) = NH (j,i);  
      X(k,3) = N3H(j,i);  
      X(k,4) = RH (j,i);  
      X(k,5) = i;  
      X(k,6) = j;  
   end  
end  
clear FH NH N3H RH;  
 
  
%F      = X( :, 1);  
%N      = X( :, 2);  
%N3     = X( :, 3);  
%R      = X( :, 4); 

%logitF		= log( F ./ (1-F) ); 
%logitFaddHalf	= log( (F+0.5)/(1.0-F+0.5) );
%logN		= log( X( :, 2) + 1 );  
%logN3		= log( X( :, 3) + 1 );  

dataSize = length(X(:,1))  
YY = X(:,1:4)';
whos

fidW = fopen('textForm4sas.data', 'w');
fprintf(fidW, '%g %g %g %g\n', YY);
fclose(fidW);

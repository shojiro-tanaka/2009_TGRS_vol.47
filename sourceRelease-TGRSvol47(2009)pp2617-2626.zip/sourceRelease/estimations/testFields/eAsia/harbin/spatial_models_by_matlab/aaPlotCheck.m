phi  = resv(:, 2);
ldet = resv(:, 3);
mse  = resv(:, 4);
aic  = resv(:, 5);
fval = resv(:, 6);
exit = resv(:, 7);
b1   = resv(:, 8);
b2   = resv(:, 9);
b3   = resv(:,10);
b4   = resv(:,11);
b5   = resv(:,12);

figure(1); plot(phi, ldet)
figure(2); plot(phi, mse)
figure(3); plot(phi, aic)
figure(4); plot(phi, fval)
figure(5); plot(phi, exit)
figure(6); plot(phi, b1)
figure(7); plot(phi, b2)
figure(8); plot(phi, b3)
figure(9); plot(phi, b4)
figure(10);plot(phi, b5)

minAIC = min(aic)

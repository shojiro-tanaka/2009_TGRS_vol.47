function mse = funK2aL1(beta)
global logitFaddHalf logN R dataSize sse mse;

clear k;
for k = 2:length(beta);
   if beta(k) < 0
      beta(k) = 1e-6*abs(randn(1));
   end
end
clear k;

B = zeros(dataSize,1);
B = beta(1) + ...
   -beta(2) * ...
     ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
      -1.0./(1.0+exp(beta(3))) ) ...
   +beta(7)*( exp(-beta(5)*exp(-beta(6)*R))-exp(-beta(5)) );

clear k;
for k = 1:dataSize 
   if B(k) > 1.0986
      B(k) = 1.0986; 
      else if B(k) < -1.0986;
         B(k) = -1.0986;
      end 
   end 
end 

C = logitFaddHalf - B;

sse = C'*C;
if sse < 0
   disp('sse negative!');
end

mse = sse/dataSize;

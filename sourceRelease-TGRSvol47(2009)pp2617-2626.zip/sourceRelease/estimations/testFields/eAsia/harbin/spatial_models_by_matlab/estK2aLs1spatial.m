clear;
t = clock;
global logitFaddHalf logN R dataSize W sse mse;

diary off
disp('*** erase former log-file. ok? (hit any-key) ***')
disp('(this matlab program list will be output to log)')
pause

!erase estK2aLs1spatial.log;
%!rm   estK2aLs1spatial.log;
diary('estK2aLs1spatial.log');
!type  estK2aLs1spatial.m;
%!cat  estK2aLs1spatial.m;
disp('      ')
disp('      ')
disp('%%% applied FUNCTION %%%')
disp('      ')
!type funK2aLs1sp.m;
%!cat funK2aLs1sp.m;
disp('      ')
disp('      ')
disp('*** actual execution begins, ok? (hit any-key) ***')
pause
disp('      ')

load 'Hharbin4logit.mat'; whos

minusD = 0.995*(1/min(lambda));
plusD  = 0.995*(1/max(lambda));

F      = X( :, 1);  
N      = X( :, 2);  
N3     = X( :, 3);  
R      = X( :, 4); 
logN   = log(N3+1);
logitFaddHalf = log( (F+0.5)./(1.0-F+0.5) );
clear dim_org N N3;

Iterphi = 100;
% IterPhi should be an even number to make balance between positive and negative iteration.
count   = 0;

beta0=[... 
      0.3544;
      0.1345;
      7.8926;
      2.7088;
     71.0000;
      0.1278 ...
]  

resv    = zeros(Iterphi,7+length(beta0));

%options=optimset('Display','iter');
options=optimset('LargeScale','off','Display','iter');
options=optimset(options,'MaxFunEvals',1000);
options=optimset(options,'MaxIter',200);
%options=optimset(options,'TolX',1e-8);
%options=optimset(options,'TolFun',1e-8);

for phi = 0:(plusD-minusD)/(Iterphi-1):plusD
   disp('      ');
   disp('*** new iteration ***');
   phi
   count = count + 1
   W = speye(dataSize) - phi*H_mat;
   fcount = 0;
   [beta, fval, exitflag, output] = fminunc('funK2aLs1sp', beta0, options)
   ldet   = - sum(log(1 - phi*lambda));
aic=dataSize*log(fval) +ldet -2*dataSize*log(1.0+2*0.5) +2*sum(log( (F+0.5).*(1.0-F+0.5) )) +2*(length(beta)+1+1);
   resv( count, : ) = [count, phi, ldet, mse, aic, fval, exitflag, beta'];
   if mse < 0
      disp('mse negative!');
      %   return
   end
end

ncount		= 0;

for phi=0:-(plusD-minusD)/(Iterphi-1):minusD
   disp('      ');
   disp('*** new iteration ***');
   phi
   count  = count+1
   ncount = ncount - 1
   W = speye(dataSize) - phi*H_mat;
   fcount = 0;
   [beta, fval, exitflag, output] = fminunc('funK2aLs1sp', beta0, options)
   ldet   = - sum(log(1 - phi*lambda));
aic=dataSize*log(fval) +ldet -2*dataSize*log(1.0+2*0.5) +2*sum(log( (F+0.5).*(1.0-F+0.5) )) +2*(length(beta)+1+1);
   resv( count, : ) = [count, phi, ldet, mse, aic, fval, exitflag, beta'];
   if mse < 0
      disp('mse negative!');
      %   return
   end
end

resv = sortrows(resv, 2);

format long;
[minAIC, I] = min(resv(:,5));
minAIC
beta=resv(I,8:13)
phi=resv(I,2)

save 'parmK2aLs1spatial.mat' resv;
elapseTime = etime(clock, t)
diary off

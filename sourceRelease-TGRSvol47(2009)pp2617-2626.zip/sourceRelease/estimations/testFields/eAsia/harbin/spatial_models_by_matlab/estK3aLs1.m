clear;  
global logitFaddHalf logN R dataSize sse mse;  
format long
  
diary off  
disp('*** erase former log-file. ok? (hit any-key) ***')  
disp('(this matlab program list will be output to log)')  
pause  
  
!erase estK3aLs1.log;  
%!rm estK3aLs1.log;  
diary('estK3aLs1.log');  
!type estK3aLs1.m;  
%!cat estK3aLs1.m;  
disp('      ')  
disp('      ')  
disp('%%% applied FUNCTION %%%')  
disp('      ')  
!type funK3aLs1.m;  
%!cat funK3aLs1.m;  
disp('      ')  
disp('      ')  
disp('*** actual execution begins, ok? (hit any-key) ***')  
pause  
disp('      ')  
  
options=optimset('Display','iter');  
%options=optimset('LargeScale','off','Display','iter');  
options=optimset(options,'MaxFunEvals',400000);  
options=optimset(options,'MaxIter',20000);  
%options=optimset('TolX',1e-16);  
options=optimset(options,'TolX',1e-16);  
options=optimset(options,'TolFun',1e-16);  
 
load 'Hharbin4logit.mat';  clear H_mat;
whos

F      = X( :, 1);  
N      = X( :, 2);  
N3     = X( :, 3);  
R      = X( :, 4); 
logN   = log(N3+1);
logitFaddHalf = log( (F+0.5)./(1.0-F+0.5) );
clear X;

beta0=[... 
   0.2332;
   1.0695;
  0.00315;
  71.0002;
   0.1343 ...
]  
 
%[beta, fval, exitflag, output] = fminunc('funK3aLs1', beta0)  
[beta, fval, exitflag, output] = fminunc('funK3aLs1', beta0, options)  
  
format long;  
sse  
dataSize  
mse  
fval  
  
aic=dataSize*log(fval) -2*dataSize*log(1.0+2*0.5) +2*sum(log( (F+0.5).*(1.0-F+0.5) )) +2*(length(beta)+1)  

beta

%parm = [ ...  
%    beta(1); beta(2); beta(3); beta(4); beta(5);  ...  
%    aic; fval; mse; sse; dataSize; exitflag]  
%fval  
%output.funcCount  
  
save 'parmK3aLs1.mat' beta;  ...  
                     aic; fval; mse; sse; dataSize; exitflag; 
diary off

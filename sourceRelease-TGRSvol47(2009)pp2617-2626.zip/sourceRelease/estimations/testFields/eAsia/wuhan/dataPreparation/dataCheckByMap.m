clear;
load aaWuhan;

%map='default';
%colormap(map);

Fmax  = max(max(FW))
Nmax  = max(max(NW))
N3max = max(max(N3W))
Rmax  = max(max(RW))
Fmin  = min(min(FW))
Nmin  = min(min(NW))
N3min = min(min(N3W))
Rmin  = min(min(RW))

fColor=[zeros(1,101);0.0:0.01:1.0;zeros(1,101)]';
%prism2(1,:)=[0 0 0];
figure(1)
colormap(brighten(fColor,0.1));
image(100*FW)

figure(2)
colormap(brighten(hot(256),0.5));
image(NW)

figure(3)
colormap(brighten(hot(256),0.5));
image(N3W)

cool2=cool(256);
cool2(1,:)=[0 0 0];
figure(4)
colormap(brighten(cool2,0.1));
image(RW/5)

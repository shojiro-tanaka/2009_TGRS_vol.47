diary off; clear;
format long;

stepLogN=[ ... % params from model:K0Ls2
 0.0000000    NaN; 
 4.4877055  -1.1784; 
 4.8806916  -1.2809;
 5.0590563  -1.2427;
 5.2457374  -1.2891;
 5.4279528  -1.3225;
 5.6174299  -1.4707;
 5.7743735  -1.2863;
 5.9819575  -1.3840;
 6.2065510  -1.3030;
 6.8355865  -1.1874 ...
]
stepLogN(:,2)=stepLogN(:,2) +0.9825; % to add the estimated value of intercept

stepR=[ ... % params from model:K2aL0
   0.0000000      NaN;
  78.2234043   1.4543;
 274.5157895   1.7735;
 473.0526316   1.9564;
 653.1157895   2.0781;
 792.2631579   2.2828;
 916.0421053   2.4075;
     1041.58   2.5096;
     1175.53   2.3548;
     1329.55   2.5153;
     1859.42   2.4541...
]
stepR(:,2)=stepR(:,2) -1.0866; % to add the estimated value of intercept


%B = beta(1) + ...
%    beta(2) * ...
%   - ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
%      -1.0./(1.0+exp(beta(3))) );
%
%clear k;
%for k = 1:dataSize
%   if R(k) > beta(5)
%      B(k) = B(k) + beta(6)*log( R(k)/beta(5) ) ;
%   end
%end

%beta(1)=  -0.1113;
%beta(2)=   0.1869;
%beta(3)=  24.9998;
%beta(4)=   5.1482;
%beta(5)= 113.3;
%beta(6)=   0.4047;

load 'parmK2aLs2b.mat';

logN=0:0.1:6.9;
estYn = ...
    beta(1) + ...
   -beta(2) * ...
     ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
      -1.0./(1.0+exp(beta(3))) ) ;

R = 0:1:1899;
estYr(1:length(R)) = beta(1); %addition of intercept value
%estYr(1:length(R)) = 0;
clear k;
for k = 1:length(R)
   if R(k) > beta(5)
      estYr(k) = estYr(k) + beta(6)*log( R(k)/beta(5) ) ;
   end
end

whos

figure(1),plot (stepLogN(:,1), stepLogN(:,2), '*', logN, estYn, '-');
title('log N vs logit (F+0.5) with estimated values by model: K0Ls2')

figure(2),plot (stepR(:,1), stepR(:,2), '*', R, estYr, '-');
title('R vs logit (F+0.5) with estimated values by step model: K2aL0')

diary off;

%2007-04-21  
format long;  
clear;  
global logitFaddHalf logN R dataSize sse mse;  
  
  
diary off  
disp('*** erase former log-file. ok? (hit any-key) ***')  
disp('(this matlab program list will be output to log)')  
pause  
  
!erase estK2aL1.log;  
%!rm estK2aL1.log;  
diary('estK2aL1.log');  
!type estK2aL1.m;  
%!cat estK2aL1.m;  
disp('      ')  
disp('      ')  
disp('%%% applied FUNCTION %%%')  
disp('      ')  
!type funK2aL1.m;  
%!cat funK2aL1.m;  
disp('      ')  
disp('      ')  
disp('*** actual execution begins, ok? (hit any-key) ***')  
pause  
disp('      ')  
  
options=optimset('Display','iter');  
%options=optimset('LargeScale','off','Display','iter');  
options=optimset(options,'MaxFunEvals',400000);  
options=optimset(options,'MaxIter',20000);  
%options=optimset('TolX',1e-16);  
options=optimset(options,'TolX',1e-16);  
options=optimset(options,'TolFun',1e-16);  

load 'Htientsin4logit.mat';  clear H_mat;
whos

F      = X( :, 1);  
N      = X( :, 2);  
N3     = X( :, 3);  
R      = X( :, 4); 
logN   = log(N3+1);
logitFaddHalf = log( (F+0.5)./(1.0-F+0.5) );
clear X;

beta0=[... 
   0.1687;
   1.0590;
  10.0000;
   1.5493;
   0.6192;
  0.00109;
   1.9153 ...
]  
 
%[beta, fval, exitflag, output] = fminunc('funK2aL1', beta0)  
[beta, fval, exitflag, output] = fminunc('funK2aL1', beta0, options)  
  
format long;  
sse  
dataSize  
mse  
fval  
  
aic=dataSize*log(fval) -2*dataSize*log(1.0+2*0.5) +2*sum(log( (F+0.5).*(1.0-F+0.5) )) +2*(length(beta)+1)  

beta

%parm = [ ...  
%    beta(1); beta(2); beta(3); beta(4); beta(5);  ...  
%    aic; fval; mse; sse; dataSize; exitflag]  
%fval  
%output.funcCount  
  
save 'parmK2aL1.mat' beta;  ...  
                     aic; fval; mse; sse; dataSize; exitflag; 
diary off

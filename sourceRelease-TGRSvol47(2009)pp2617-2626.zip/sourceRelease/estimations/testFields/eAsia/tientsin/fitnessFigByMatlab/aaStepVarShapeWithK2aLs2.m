diary off; clear;
format long;

stepLogN=[ ... % params from model:K0Ls2
 0.0000000    NaN; 
 4.1195715  -0.9509; 
 4.6453493  -0.7162;
 4.9624911  -0.8529;
 5.2760037  -0.9486;
 5.5894552  -1.0105;
 5.8370713  -1.1285;
 6.0784365  -1.5592;
 6.2171352  -1.6165;
 6.3773359  -1.6251;
 6.8525651  -1.5343 ...
]
stepLogN(:,2)=stepLogN(:,2) +1.0737; % to add the estimated value of intercept

stepR=[ ... % params from model:K2aL0
   0.0000000      NaN;
  25.5641026   0.5900   ;
  57.4750000   0.3695   ;
  185.7368421  0.9177   ;
  326.4615385  0.5693   ;
  463.9230769  0.8112   ;
  602.8250000  0.7568   ;
  774.7368421  0.8449   ;
  954.6666667  0.7980   ;
 1147.13       1.1615   ;
 1531.30       1.2715  ...
]
stepR(:,2)=stepR(:,2) -0.2600; % to add the estimated value of intercept


%B = beta(1) + ...
%    beta(2) * ...
%   - ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
%      -1.0./(1.0+exp(beta(3))) );
%
%clear k;
%for k = 1:dataSize
%   if R(k) > beta(5)
%      B(k) = B(k) + beta(6)*log( R(k)/beta(5) ) ;
%   end
%end

load 'parmK2aLs2.mat';

logN=0:0.1:6.9;
estYn = ...
    beta(1) + ...
   -beta(2) * ...
     ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
      -1.0./(1.0+exp(beta(3))) ) ;

R = 0:1:1599;
estYr(1:length(R)) = beta(1); %addition of intercept value
%estYr(1:length(R)) = 0;
clear k;
for k = 1:length(R)
   if R(k) > beta(5)
      estYr(k) = estYr(k) + beta(6)*log( R(k)/beta(5) ) ;
   end
end

whos

figure(1),plot (stepLogN(:,1), stepLogN(:,2), '*', logN, estYn, '-');
title('log N vs logit (F+0.5) with estimated values by model: K0Ls2')

figure(2),plot (stepR(:,1), stepR(:,2), '*', R, estYr, '-');
title('R vs logit (F+0.5) with estimated values by step model: K2aL0')

diary off;

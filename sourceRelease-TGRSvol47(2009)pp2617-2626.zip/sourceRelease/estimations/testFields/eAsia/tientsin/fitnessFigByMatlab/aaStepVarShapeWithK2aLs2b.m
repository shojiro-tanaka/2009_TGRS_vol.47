diary off; clear;
format long;

stepLogN=[ ... % params from model:K0Ls2
 0.0000000    NaN; 
 4.1195715    0.0936; 
 4.6453493    0.3232;
 4.9624911    0.1946;
 5.2760037    0.0882;
 5.5894552    0.0236;
 5.8370713   -0.0847;
 6.0784365   -0.5124;
 6.2171352   -0.5743;
 6.3773359   -0.5674;
 6.8525651   -0.4895 ...
]
stepLogN(:,2)=stepLogN(:,2) +0.0255; % to add the estimated value of intercept

stepR=[ ... % params from model:K2aL0
   0.0000000      NaN;
  25.5641026     0.2098 ;
  57.4750000    -0.0681 ;
  185.7368421    0.5909 ;
  326.4615385    0.1486 ;
  463.9230769    0.4257 ;
  602.8250000    0.3454 ;
  774.7368421    0.4485 ;
  954.6666667    0.3910 ;
 1147.13         0.7519 ;
 1531.30         0.8514 ...
]
stepR(:,2)=stepR(:,2) +0.0845; % to add the estimated value of intercept


%B = beta(1) + ...
%    beta(2) * ...
%   - ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
%      -1.0./(1.0+exp(beta(3))) );
%
%clear k;
%for k = 1:dataSize
%   if R(k) > beta(5)
%      B(k) = B(k) + beta(6)*log( R(k)/beta(5) ) ;
%   end
%end

load 'parmK2aLs2b.mat';

logN=0:0.1:7.9;
estYn = ...
    beta(1) + ...
   -beta(2) * ...
     ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
      -1.0./(1.0+exp(beta(3))) ) ;

R = 0:1:2199;
estYr(1:length(R)) = beta(1); %addition of intercept value
%estYr(1:length(R)) = 0;
clear k;
for k = 1:length(R)
   if R(k) > beta(5)
      estYr(k) = estYr(k) + beta(6)*log( R(k)/beta(5) ) ;
   end
end

whos

figure(1),plot (stepLogN(:,1), stepLogN(:,2), '*', logN, estYn, '-');
title('log N vs logit (F+0.5) with estimated values by model: K0Ls2')

figure(2),plot (stepR(:,1), stepR(:,2), '*', R, estYr, '-');
title('R vs logit (F+0.5) with estimated values by step model: K2aL0')

diary off;

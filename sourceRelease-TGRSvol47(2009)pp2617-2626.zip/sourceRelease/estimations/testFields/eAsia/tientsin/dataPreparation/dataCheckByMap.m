clear;
load aaTientsin;

%map='default';
%colormap(map);

Fmax  = max(max(FT))
Nmax  = max(max(NT))
N3max = max(max(N3T))
Rmax  = max(max(RT))
Fmin  = min(min(FT))
Nmin  = min(min(NT))
N3min = min(min(N3T))
Rmin  = min(min(RT))

fColor=[zeros(1,101);0.0:0.01:1.0;zeros(1,101)]';
%prism2(1,:)=[0 0 0];
figure(1)
colormap(brighten(fColor,0.1));
image(100*FT)

figure(2)
colormap(brighten(hot(256),0.5));
image(NT)

figure(3)
colormap(brighten(hot(256),0.5));
image(N3T)

cool2=cool(256);
cool2(1,:)=[0 0 0];
figure(4)
colormap(brighten(cool2,0.1));
image(RT/5)

!!
FINAL:
$\omega_1$ and $\psi_1$ are set to zero as a baseline, respectively,
while $\beta_0$ is always available.
!!

%2007-04-23  
format long;  
clear;  
global F logN R dataSize sse mse;  
  
  
diary off  
disp('*** erase former log-file. ok? (hit any-key) ***')  
disp('(this matlab program list will be output to log)')  
pause  
  
!erase estK2aL1.log;  
%!rm estK2aL1.log;  
diary('estK2aL1.log');  
!type estK2aL1.m;  
%!cat estK2aL1.m;  
disp('      ')  
disp('      ')  
disp('%%% applied FUNCTION %%%')  
disp('      ')  
!type funK2aL1.m;  
%!cat funK2aL1.m;  
disp('      ')  
disp('      ')  
disp('*** actual execution begins, ok? (hit any-key) ***')  
pause  
disp('      ')  
  
options=optimset('Display','iter');  
%options=optimset('LargeScale','off','Display','iter');  
options=optimset(options,'MaxFunEvals',400000);  
%options=optimset('MaxFunEvals',400000);  
options=optimset(options,'MaxIter',20000);  
%options=optimset('TolX',1e-16);  
options=optimset(options,'TolX',1e-16);  
options=optimset(options,'TolFun',1e-32);  
 
load 'vectors4nLinRegression.mat';  
dataSize = length(F)  
clear dr00 dr01 dr02 dr03 dr04 dr05 dr06 dr07 dr08 dr09 dr10 dr11 dr12 dr13 dr14 dr15 ...  
      dn00 dn01 dn02 dn03 dn04 dn05 dn06 dn07 dn08;  
Forest = F; clear F;
xdata = [logN R];

beta0 = [ ...
 0.6038;
 0.5597;
 4.9718;
 0.8662;
 3.7987;
 0.0231;
 0.3714 ...
]
LB = [ ...
     -1.1;
        0;
        0;
        0;
        0;
        0;
        0 ...
]
UB = [ ...
      1.1;
     20.0;
     10.0;
      1.0;
      5.0;
      0.5;
      7.0 ...
]

format long; 
[beta, RESNORM, RESIDUAL, exitflag, output, LAMBDA, JACOBIAN] = ...
 lsqcurvefit(@funK2aL1, beta0, xdata, Forest, LB, UB, options) ;

beta

RESNORM
sse = RESIDUAL'*RESIDUAL
mse = RESNORM/dataSize
mse2= sse/dataSize

aic =dataSize*log(mse ) +2*(length(beta)+1)  
aic2=dataSize*log(mse2) +2*(length(beta)+1)  

save 'parmK2aL1.mat' beta dataSize RESNORM aic; 
diary off

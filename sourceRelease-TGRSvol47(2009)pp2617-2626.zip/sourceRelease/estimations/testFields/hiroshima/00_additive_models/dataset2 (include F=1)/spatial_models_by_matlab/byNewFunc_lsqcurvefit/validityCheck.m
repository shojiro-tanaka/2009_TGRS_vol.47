load 'vectors4nLinRegression.mat';  
%dataSize = length(F)  
clear dr00 dr01 dr02 dr03 dr04 dr05 dr06 dr07 dr08 dr09 dr10 dr11 dr12 dr13 dr14 dr15 ...  
      dn00 dn01 dn02 dn03 dn04 dn05 dn06 dn07 dn08;  
Forest = F; clear F;
xdata = [logN R];

load 'parmK2aL1.mat';  

Pred = beta(1) + ...
   -beta(2) * ...
     ( 1.0./(1.0+exp(beta(3)-beta(4)*xdata(:,1))) ...
      -1.0./(1.0+exp(beta(3))) ) ...
   +beta(7)*( exp(-beta(5)*exp(-beta(6)*xdata(:,2)))-exp(-beta(5)) );

resid = Forest - Pred;
sse = resid'*resid


%2007-04-21  
format long;  
clear;  
global F logN R dataSize sse mse;  
  
  
diary off  
disp('*** erase former log-file. ok? (hit any-key) ***')  
disp('(this matlab program list will be output to log)')  
pause  
  
!erase estK2aLs2.log;  
%!rm estK2aLs2.log;  
diary('estK2aLs2.log');  
!type estK2aLs2.m;  
%!cat estK2aLs2.m;  
disp('      ')  
disp('      ')  
disp('%%% applied FUNCTION %%%')  
disp('      ')  
!type funK2aLs2.m;  
%!cat funK2aLs2.m;  
disp('      ')  
disp('      ')  
disp('*** actual execution begins, ok? (hit any-key) ***')  
pause  
disp('      ')  
  
options=optimset('Display','iter');  
%options=optimset('LargeScale','off','Display','iter');  
options=optimset(options,'MaxFunEvals',400000);  
options=optimset(options,'MaxIter',20000);  
%options=optimset('TolX',1e-16);  
options=optimset(options,'TolX',1e-16);  
options=optimset(options,'TolFun',1e-16);  
 
load 'vectors4nLinRegression.mat';  
dataSize = length(F)  
clear dr00 dr01 dr02 dr03 dr04 dr05 dr06 dr07 dr08 dr09 dr10 dr11 dr12 dr13 dr14 dr15 ...  
      dn00 dn01 dn02 dn03 dn04 dn05 dn06 dn07 dn08;  
logitFaddHalf = log( (F+0.5)./(1.0-F+0.5) );

beta0=[... 
    0.6177;
    0.5588;
    5.1578;
    0.8991;
   21.9999;
    0.1476 ...
]  
 
%[beta, fval, exitflag, output] = fminunc('funK2aLs2', beta0)  
[beta, fval, exitflag, output] = fminunc('funK2aLs2', beta0, options)  
  
format long;  
sse  
dataSize  
mse  
fval  
  
aic=dataSize*log(fval) +2*(length(beta)+1)  

beta

%parm = [ ...  
%    beta(1); beta(2); beta(3); beta(4); beta(5);  ...  
%    aic; fval; mse; sse; dataSize; exitflag]  
%fval  
%output.funcCount  
  
save 'parmK2aLs2.mat' beta;  ...  
                     aic; fval; mse; sse; dataSize; exitflag; 
diary off

%This program makes and saves a spatial weight matrix of
%neibors, Hs, corresponding to a spatial location matrix, xy,
%which contains x and y information of original data.
%
%xy:  		location info(x, y) for valid data
%H:   		temporary sparse matrix, mn*mn
%P:   		projection matrix derived from above xy
%H_mat		target spatial weight matrix
%lambda:	eigen values of H_mat
%
%S. Tanaka under instructions from R. Nishii, 1998-99
% Final version 2005/08/04  Tanaka & Nishii

t = clock;

fid	 = fopen('../all-n8697.data','rt');
tmp	 = fscanf(fid,'%f',[6,inf]);
Y	 = tmp'; clear tmp;

L	 = Y(:,3)>0.0;
X	 = Y(L,:); 
clear Y L;

%diary( 'weightMake.log' )

[dsize, dim_org] = size(X);
dsize

x	= X(:,1); Xmin=min(x);
y	= X(:,2); Ymin=min(y);
x	= x-Xmin+1;
y	= y-Ymin+1;

Xmax	= max(x);
Ymax	= max(y);
xy		= sparse(x, y, 1, Xmax, Ymax);
%image(xy)

H      = sparse( Xmax*Ymax,Xmax*Ymax );
[m, n] = size(H);

for j=2:(Ymax-1)
   for i=2:(Xmax-1)
      H(Xmax*(j-1)+i, Xmax*(j-1)     +i-1)  = 1;
      H(Xmax*(j-1)+i, Xmax*(j-1)     +i+1)  = 1;
      H(Xmax*(j-1)+i, Xmax*(j-1-1)   +i  )  = 1;
      H(Xmax*(j-1)+i, Xmax*(j-1+1)   +i  )  = 1;
   end
end

for j = 1:Ymax
   for i = 1:Xmax-1:Xmax
      if (Xmax*(j-1) + i-1 > 0)
         H(Xmax*(j-1)+i, Xmax*(j-1) + i-1) = 1;
      end
      if (Xmax*(j-1) + i+1 <= Xmax*Ymax)
         H(Xmax*(j-1)+i, Xmax*(j-1) + i+1) = 1;
      end
      if (Xmax*(j-2) + i   > 0)
         H(Xmax*(j-1)+i, Xmax*(j-2) + i  ) = 1;
      end
      if (Xmax*(j  ) + i   <= Xmax*Ymax)
         H(Xmax*(j-1)+i, Xmax*(j   ) + i  ) = 1;
      end
   end
end

for j = 1:Ymax-1:Ymax
   for i = 1:Xmax
      if (Xmax*(j-1) + i-1 > 0)
         H(Xmax*(j-1)+i, Xmax*(j-1) + i-1) = 1;
      end
      if (Xmax*(j-1) + i+1 <= Xmax*Ymax)
         H(Xmax*(j-1)+i, Xmax*(j-1) + i+1) = 1;
      end
      if (Xmax*(j-2) + i   > 0)
         H(Xmax*(j-1)+i, Xmax*(j-2) + i  ) = 1;
      end
      if (Xmax*(j  ) + i   <= Xmax*Ymax)
         H(Xmax*(j-1)+i, Xmax*(j  ) + i  ) = 1;
      end
   end
end

[mc, nc]	= size(H);
if mc ~= m | nc ~= n
   error('ERROR: Matrix size illegally changed');
end

P		= sparse( Xmax*Ymax, dsize );
count	= 0;

for j=1:Ymax
   for i=1:Xmax
      if xy(i,j) == 1
         count=count+1;
         P(Xmax*(j-1)+i, count)=1;
      end
   end
end

if count ~= dsize
   error('ERROR: Projection matrix formulation failed');
end

H_mat = P'*H*P;
lambda = eig(H_mat);

elapseTime = etime(clock, t)
save 'H4logit.mat' H_mat lambda X dim_org dsize
%diary off

models and data from:

I:\TANAKA\tanaka\myDOCs\academicDocs\SPIE\2005_Bruges_Belgium\hiroshima\logitHiroshima_by_Matlab_4_bestModels
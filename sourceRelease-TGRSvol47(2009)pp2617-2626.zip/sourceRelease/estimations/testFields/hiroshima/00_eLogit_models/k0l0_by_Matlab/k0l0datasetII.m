clear; 
diary off   
disp('*** erase former log-file. ok? (hit any-key) ***')   
disp('(this matlab program list will be output to log)')   
pause   
   
!erase k0l0(n=8538).log;   
%!rm k0l0(n=8538).log;   
diary('k0l0(n=8538).log');   
!type k0l0datasetII.m;   
%!cat k0l0datasetII.m;   
disp('      ')   
disp('      ')   
disp('*** actual execution begins, ok? (hit any-key) ***')   
pause   
disp('      ')   
 
load 'matrix4regression(n=8538).mat';  
%whos 

format long; 
beta=inv(XX'*XX)*XX'*logitFaddHalf 
betaR = beta(2:16) 
betaN = beta(17:24)
intercep = beta(1)
numBeta = length(beta)
 
B = logitFaddHalf - XX*beta; 
 
mse = B'*B/(dataSize-length(beta)) 
aic=dataSize*( log(mse)-2*log(1.0+2*0.5) )+2*sum(log((F+0.5).*(1.0-F+0.5)))+2*(length(beta)+1)   
dataSize
 
diary off

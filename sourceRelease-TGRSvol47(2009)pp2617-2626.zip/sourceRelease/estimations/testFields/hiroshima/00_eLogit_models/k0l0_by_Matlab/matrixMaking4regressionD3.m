diary off; clear; 

fid = fopen('all-n8697.data','rt');
tmp = fscanf(fid,'%f',[6,inf]);
Y   = tmp'; clear tmp fid;

%%% 0.0 < F < 1.0
L = Y(:,3)>0.0;
Z = Y(L,:); 
M = Z(:,3)<1.0;
X = Z(M,:);
clear Y Z L M;

%%% 0.0 < F <= 1.0
%L	 = Y(:,3)>0.0;
%X	 = Y(L,:); 
%clear Y L;

[dataSize, dim_org] = size(X);
dataSize
  
F = X( :, 3);  
%logitF = log( F ./ (1-F) ); 
N = X( :, 4);  
logN = log( X( :, 4) + 1 );  
R = X( :, 5);

logitFaddHalf = log( (F+0.5) ./ (1.0-F+0.5) );

%%% (step formulation for Rilief energy) %%%
dr00  = R < 20;

r01a = X(:,5) >= 20;
r01b = X(:,5) < 40;
dr01  = logical(r01a.*r01b); clear r01a r01b;

r02a = X(:,5) >= 40;
r02b = X(:,5) < 60;
dr02  = logical(r02a.*r02b); clear r02a r02b;

r03a = X(:,5) >= 60;
r03b = X(:,5) < 80;
dr03  = logical(r03a.*r03b); clear r03a r03b;

r04a = X(:,5) >= 80;
r04b = X(:,5) < 100;
dr04  = logical(r04a.*r04b); clear r04a r04b;

r05a = X(:,5) >= 100;
r05b = X(:,5) < 120;
dr05  = logical(r05a.*r05b); clear r05a r05b;

r06a = X(:,5) >= 120;
r06b = X(:,5) < 140;
dr06  = logical(r06a.*r06b); clear r06a r06b;

r07a = X(:,5) >= 140;
r07b = X(:,5) < 160;
dr07  = logical(r07a.*r07b); clear r07a r07b;

r08a = X(:,5) >= 160;
r08b = X(:,5) < 180;
dr08  = logical(r08a.*r08b); clear r08a r08b;

r09a = X(:,5) >= 180;
r09b = X(:,5) < 200;
dr09  = logical(r09a.*r09b); clear r09a r09b;

r10a = X(:,5) >= 200;
r10b = X(:,5) <  220;
dr10  = logical(r10a.*r10b); clear r10a r10b;

r11a = X(:,5) >= 220;
r11b = X(:,5) < 240;
dr11  = logical(r11a.*r11b); clear r11a r11b;

r12a = X(:,5) >= 240;
r12b = X(:,5) < 260;
dr12  = logical(r12a.*r12b); clear r12a r12b;

r13a = X(:,5) >= 260;
r13b = X(:,5) < 280;
dr13  = logical(r13a.*r13b); clear r13a r13b;

r14a = X(:,5) >= 280;
r14b = X(:,5) < 300;
dr14  = logical(r14a.*r14b); clear r14a r14b;

dr15 = X(:,5) >= 300;
%%% /(step formulation for Rilief energy) %%%

%%% (step formulation for Human population density) %%%
logN = log(X(:,4)+1);

dn00  = logN < 3.0;

n01a = logN >  0.0;
n01b = logN <  3.0;
dn01  = logical(n01a.*n01b); clear n01a n01b;

n02a = logN >= 3.0;
n02b = logN <  4.0;
dn02  = logical(n02a.*n02b); clear n02a n02b;

n03a = logN >= 4.0;
n03b = logN <  4.5;
dn03 = logical(n03a.*n03b); clear n03a n03b;

n04a = logN >= 4.5;
n04b = logN <  5.0;
dn04 = logical(n04a.*n04b); clear n04a n04b;

n05a = logN >= 5.0;
n05b = logN <  5.5;
dn05 = logical(n05a.*n05b); clear n05a n05b;

n06a = logN >= 5.5;
n06b = logN <  6.0;
dn06 = logical(n06a.*n06b); clear n06a n06b;

n07a = logN >= 6.0;
n07b = logN <  7.0;
dn07 = logical(n07a.*n07b); clear n07a n07b;

n08a = logN >= 7.0;
n08b = logN <  8.0;
dn08 = logical(n08a.*n08b); clear n08a n08b;

dn09 = logN >= 8.0;
%%% /(step formulation for Human population density) %%%

%%% (matrix formulation for linear regression) %%%
a0 = ones(dataSize,1);
XX = [ a0 ... %r00
  dr01 dr02 dr03 dr04 dr05 dr06 dr07 dr08 dr09 dr10 dr11 dr12 dr13 dr14 dr15 ...
  dn01 dn02 dn03 dn04 dn05 dn06 dn07 dn08 dn09];
dmy1 = [dr00 XX(:,2:16)]'; sum( sum(dmy1) )
dmy2 = [dn00 XX(:,17:25)]'; sum( sum(dmy2) )
clear X dim_org;
%clear H8533 dsize lambda;
clear dr00 dr01 dr02 dr03 dr04 dr05 dr06 dr07 dr08 dr09 dr10 dr11 dr12 dr13 dr14 dr15;
clear a0 dn00 dn01 dn02 dn03 dn04 dn05 dn06 dn07 dn08 dn09;
clear ans dmy1 dmy2;
%%% /(matrix formulation for linear regression) %%%

save 'matrix4regression(n=6825).mat' XX logitFaddHalf logN F N R dataSize;

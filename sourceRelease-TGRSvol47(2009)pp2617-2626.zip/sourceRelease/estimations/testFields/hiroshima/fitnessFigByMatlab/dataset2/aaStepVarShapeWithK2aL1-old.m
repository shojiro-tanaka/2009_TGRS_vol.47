diary off; clear;
format long;

stepLogN=[ ... % params from model:K0L1, beta0 = 0.2198
 0.00  NaN    ; 
 1.50   -0.0484; 
 3.50   -0.1742; 
 4.25   -0.2472; 
 4.75   -0.3814; 
 5.25   -0.4673; 
 5.75   -0.6299; 
 6.50   -0.7757; 
 7.50   -0.9452; 
 9.00   -1.1032 ... 
]
stepLogN(:,2)=stepLogN(:,2)+ 0.2198; % to add the estimated value of intercept

stepR=[ ... % params from model:K2aL0, beta0 =  0.2603 
   0.0   NaN   ; 
  30.0  -0.0172; 
  50.0   0.1512; 
  70.0   0.3184; 
  90.0   0.4466; 
 110.0   0.5189; 
 130.0   0.5808; 
 150.0   0.6271; 
 170.0   0.6528; 
 190.0   0.7049; 
 210.0   0.7071; 
 230.0   0.7272; 
 250.0   0.7447; 
 270.0   0.7601; 
 290.0   0.7571; 
 340.0   0.8031 ...
]
stepR(:,2)=stepR(:,2)+  0.2603; % to add the estimated value of intercept


%B = beta(1) + ...
%   -beta(2) * ...
%     ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
%      -1.0./(1.0+exp(beta(3))) ) ...
%   +beta(7)*( exp(-beta(5)*exp(-beta(6)*R))-exp(-beta(5)) );

%beta(1) =   0.2262;
%beta(2) =   1.2126;
%beta(3) =   4.7101;
%beta(4) =   0.8254;
%beta(5) =   3.4144;
%beta(6) =   0.0215;
%beta(7) =   0.8192;

load 'parmK2aL1.mat';

logN=0:0.1:10.9;
estYn = ...
    beta(1) + ...
   -beta(2) * ...
     ( 1.0./(1.0+exp(beta(3)-beta(4)*logN)) ...
      -1.0./(1.0+exp(beta(3))) ) ;

R = 0:1:349;
estYr(1:length(R)) = beta(1); %addition of intercept value
%estYr(1:length(R)) = 0;
estYr = estYr + beta(7)*( exp(-beta(5)*exp(-beta(6)*R))-exp(-beta(5)) );

%estYr = beta(7)*( exp(-beta(5)*exp(-beta(6)*R))-exp(-beta(5)) );


whos

figure(1),plot (stepLogN(:,1), stepLogN(:,2), '-', logN, estYn, '-');
%figure(1),plot (stepLogN(:,1), stepLogN(:,2), '*', logN, estYn, '-');
title('log N vs logit (F+0.5) with estimated values by model: K0L1')

figure(2),plot (stepR(:,1), stepR(:,2), '*', R, estYr, '-');
title('R vs logit (F+0.5) with estimated values by step model: K2aL0')

diary off;

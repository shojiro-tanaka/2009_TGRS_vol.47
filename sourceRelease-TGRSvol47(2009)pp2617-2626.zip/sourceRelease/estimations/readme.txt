All source programs needed to estimate parameters of all the models
are in this directory, and/or the subdirectories. 

For the details, please see the source programs.

These programs are distributed in the hope that they will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
General Public License for more details. 

http://www.gnu.org/licenses/licenses.html

As for the intermediate files left for the purpose of algorithm
checks, please follow intructions of the original copyright holders.

Shojiro Tanaka, October, 2008
mailto:tanaka@cis.shimane-u.ac.jp .


close all; f=0:0.01:1; ind=0; 
figure,
for r=0.1:0.1:1.2; 
 ind = ind + 1; l=(2*r+1)/4 *(log(f+r)-log(1-f+r));
 subplot(3,4,ind);  plot(f,l); axis([0, 1, -.8, .8]);
end
text(-2.35, 5.4, 'y = (2r + 1)/4 * (log(x+r) - log(1-x+r)) for r = 0.1:0.1:1.2')


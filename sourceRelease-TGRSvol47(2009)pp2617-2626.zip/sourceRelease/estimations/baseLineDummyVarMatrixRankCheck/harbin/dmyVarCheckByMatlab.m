clear; 
diary off   

load 'dmyVarForCheck.txt';

XX = dmyVarForCheck; clear dmyVarForCheck;

XX(:,20)-sum(XX(:,1:10),2)+sum(XX(:,11:19),2)

 
diary off
